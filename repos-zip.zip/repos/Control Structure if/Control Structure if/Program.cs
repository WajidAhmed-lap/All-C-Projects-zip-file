using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control_Structure_if
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ahmed";

            Console.WriteLine("                                 Question No : 1 ");
//                      Q NO 1
            Console.Write("\n\n\nPlease Enter a code word : ");
            string code = Console.ReadLine();
            //          A 

            if (code == "A")
            Console.WriteLine("Accouting");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================

//                      Q NO 2
            Console.WriteLine("                                 Question No : 2 ");
            Console.Write("\n\n\nIf you enter a correct number then i'll tell you spell : ");
            byte number = Convert.ToByte(Console.ReadLine());
            //          7 

            if (number == 7)
            Console.WriteLine("Seven");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================

            
            //              Q NO 3
            Console.WriteLine("                                 Question No : 3 ");
            Console.Write("\n\n\nEnter value then i'll tell you it's correct or not  : ");
            float pie = Convert.ToSingle(Console.ReadLine());
            //          3.14 

            if (pie == 3.14F)
            Console.WriteLine("Correct Value");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================





            //              Q NO 4
            Console.WriteLine("                                 Question No : 4 ");
            Console.Write("\n\n\nTell me correct number in spell like 1,2,3   : ");
            string check= Console.ReadLine();
            //          one

            if (check == "one")
                Console.WriteLine("1");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================


            //              Q NO 5
            Console.WriteLine("                                 Question No : 5 ");
            Console.Write("\n\n\nTake Boolean value input and check if value is true then print 'Married'  : ");
            bool true_false = Convert.ToBoolean(Console.ReadLine());
            //          true 

            if (true_false==true)
                Console.WriteLine("Married");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================


            //              Q NO 6
            Console.WriteLine("                                 Question No : 6 ");
            Console.Write("\n\n\nChoose any first letter of programming language   : ");
            char P = Convert.ToChar(Console.ReadLine());
            //         P 

            if (P == 'P')
                Console.WriteLine("PHP");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================

            //              Q NO 7
            Console.WriteLine("                                 Question No : 7 ");
            Console.Write("\n\n\nEnter any  number   : ");
            byte n9 = Convert.ToByte(Console.ReadLine());
            //          9

            if (n9 == 9)
                Console.WriteLine("Nine");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================


            //              Q NO 8
            Console.WriteLine("                                 Question No : 8 ");
            Console.Write("\n\n\nEnter correct value to see correct message  : ");
            float correct = Convert.ToSingle(Console.ReadLine());
            //          6.18 

            if (correct == 6.18F)
                Console.WriteLine("Correct Value ");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================



            //              Q NO 9
            Console.WriteLine("                                 Question No : 9 ");
            Console.Write("\n\n\nIs he educated : ");
            bool educated = Convert.ToBoolean(Console.ReadLine());
            //          true

            if (educated==true)
                Console.WriteLine("Educated");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================

            //              Q NO 10
            Console.WriteLine("                                 Question No : 10 ");
            Console.Write("\n\n\nEnter your number in spell : ");
            string spell = Console.ReadLine();
            //          ten

            if (spell=="ten")
                Console.WriteLine("10");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================


            //              Q NO 11
            Console.WriteLine("                                 Question No : 11");
            Console.Write("\n\n\nEnter the shortform of your word : ");
            char  shortForm= Convert.ToChar(Console.ReadLine());
            //          M

            if (shortForm == 'M')
                Console.WriteLine("MS Offifse");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================

            //              Q NO 12
            Console.WriteLine("                                 Question No : 12 ");
            Console.Write("\n\n\nWhat you wanna translate into English  : ");
            byte translate = Convert.ToByte(Console.ReadLine());
            //          10

            if (translate==10)
                Console.WriteLine("Ten");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================



            //              Q NO 13
            Console.WriteLine("                                 Question No : 13 ");
            Console.Write("\n\n\nEnter gram value : ");
            float gram = Convert.ToSingle(Console.ReadLine());
            //          9.33

            if (gram == 9.33f)
                Console.WriteLine("Correct Value");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================


            //              Q NO 14
            Console.WriteLine("                                 Question No : 14 ");
            Console.Write("\n\n\nIs He Student : ");
            bool student = Convert.ToBoolean(Console.ReadLine());
            //          true

            if (student== true)
                Console.WriteLine("Student");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================

            //              Q NO 15
            Console.WriteLine("                                 Question No : 15 ");
            Console.Write("\n\n\nEnter fifteen  : ");
            string fifteen = Console.ReadLine();
            //          fifteen

            if (fifteen=="fifteen")
                Console.WriteLine("15");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================


            //              Q NO 16
            Console.WriteLine("                                 Question No : 16");
            Console.Write("\n\n\nEnter any short letter of programming languang: ");
            char letter = Convert.ToChar(Console.ReadLine());
            //          J

            if (letter=='J')
                Console.WriteLine("Java");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================


            //              Q NO 17
            Console.WriteLine("                                 Question No : 17 ");
            Console.Write("\n\n\nEnter counting to see changing it into spell: ");
            byte count= Convert.ToByte(Console.ReadLine());
            //          15

            if (count==15)
                Console.WriteLine("Fifteen");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================

            //              Q NO 18
            Console.WriteLine("                                 Question No : 18 ");
            Console.Write("\n\n\nGram value ???: ");
            float value= Convert.ToSingle(Console.ReadLine());
            //          10.24

            if (value==10.24f)
                Console.WriteLine("Correct Value");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================

            //              Q NO 19
            Console.WriteLine("                                 Question No : 19");
            Console.Write("\n\n\nAre you Married : ");
            bool married = Convert.ToBoolean(Console.ReadLine());
            //          false

            if (married==false )
                Console.WriteLine("Unmarried");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================


            //              Q NO 20
            Console.WriteLine("                                 Question No :  20");
            Console.Write("\n\n\nAgain tell me counting in spell : ");
            string spellCount= Console.ReadLine();
            //          fifty

            if (spellCount=="fifty")
                Console.WriteLine("50");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================


            //              Q NO 21
            Console.WriteLine("                                 Question No : 21");
            Console.Write("\n\n\nDo you have more letters of programming language : ");
            char yes= Convert.ToChar(Console.ReadLine());
            //          H

            if (yes == 'H')
                Console.WriteLine("HTML");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================


            //              Q NO 22
            Console.WriteLine("                                 Question No : 22");
            Console.Write("\n\n\nNumber please ]: ");
            byte intgr= Convert.ToByte(Console.ReadLine());
            //          20

            if (intgr== 20)
                Console.WriteLine("Twenty");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================

            //              Q NO 23
            Console.WriteLine("                                 Question No : 23 ");
            Console.Write("\n\n\nFloat value please: ");
            float hmm= Convert.ToSingle(Console.ReadLine());
            //          13.19

            if (hmm  == 13.19f)
                Console.WriteLine("Correct value");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================

            //              Q NO 24
            Console.WriteLine("                                 Question No : 24 ");
            Console.Write("\n\n\nEducated or not : ");
            bool not= Convert.ToBoolean(Console.ReadLine());
            //          true

            if (not == true)
                Console.WriteLine("Uneducated");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================


            //              Q NO 25
            Console.WriteLine("                                 Question No : 25");
            Console.Write("\n\n\nEnter number in spell: ");
            string inSpell= Console.ReadLine();
            //          hudred

            if (inSpell=="hudred")
                Console.WriteLine("100");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================

            //              Q NO 26
            Console.WriteLine("                                 Question No : 26");
            Console.Write("\n\n\nOne more time enter the first letter : ");
            char beforLast= Convert.ToChar(Console.ReadLine());
            //          D

            if (beforLast=='D')
                Console.WriteLine("DOT NET");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================

            //              Q NO 27
            Console.WriteLine("                                 Question No : 27 ");
            Console.Write("\n\n\nAre you a student : ");
            bool no = Convert.ToBoolean(Console.ReadLine());
            //          false

            if (no == false)
                Console.WriteLine("Not a Student");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================


            //              Q NO 28
            Console.WriteLine("                                 Question No : 28 ");
            Console.Write("\n\n\nTell me the last letter of any language : ");
            char last= Convert.ToChar(Console.ReadLine());
            //          S

            if (last == 'S')
                Console.WriteLine("SQL");
            Console.ReadLine();
            Console.Clear();
            //=============================================================================





















            Console.ReadLine();
        }
    }
}