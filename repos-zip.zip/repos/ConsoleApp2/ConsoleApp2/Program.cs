using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Bitiwse Operators
            //          Bitwise AND         &
            //          Bitwise OR          |
            //          Bitwise XOR         ^
            //          Shift Operators
            //                  Left Shift          <<
            //                  Right Shift         >>

            //    Console.WriteLine(10 << 1);
            //    Console.WriteLine(7 << 1);
            //    Console.WriteLine(5 << 1);

            //    Console.WriteLine(10 << 2);
            //Console.WriteLine(5 << 3);

            //Console.WriteLine(130 << 1);
            //Console.WriteLine(130 << 2);


            //Console.WriteLine(10 >> 1);
            //Console.WriteLine(6 >> 1);
            Console.WriteLine(3 >> 1);
            Console.WriteLine(3 >> 2);





        }
    }
}
