﻿

Console.Title = "AHMED";

Console.Write("Enter your age >= 18 :");
byte age = Convert.ToByte(Console.ReadLine());

switch (age >= 18)
{
    case true:
        Console.WriteLine("You can vote.");
        break;
    default:
        Console.WriteLine("You can not.");
        break;
}
Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter temperature : ");
byte temp = Convert.ToByte(Console.ReadLine());

switch (temp >= 30 )
{
    case true:
        Console.WriteLine("It's hot outside.");
        break;
}
switch (temp <= 10 )
{
    case true:
        Console.WriteLine("It's cold outside.");
        break;

}
Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter first number 90 : ");
byte num  = Convert.ToByte(Console.ReadLine());

Console.WriteLine("Enter second number 70 : ");
byte second  = Convert.ToByte(Console.ReadLine());

switch (num > second)
{
    case true:
        Console.WriteLine("First number is greater than second.");
        break;
}

switch (num < second)
{
    case true:
        Console.WriteLine("First number is smaller than second.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================



Console.Write("Enter your marks :");
byte marks  = Convert.ToByte(Console.ReadLine());

switch (marks >= 50 )
{
    case true:
        Console.WriteLine("Pass.");
        break;
    default:
        Console.WriteLine("Fail.");
        break;
}
Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enter temperature -90 : ");
sbyte tempe = Convert.ToSByte(Console.ReadLine());

switch (tempe < 0 )
{
    case true:
        Console.WriteLine("Water is in solid state.");
        break;
    default:
        Console.WriteLine("Water is in liquid state.");
        break;
}
Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter any number : ");
int nm = Convert.ToInt32(Console.ReadLine());

switch (nm >=0 )
{
    case true:
        Console.WriteLine("Number is positive.");
        break;

}

switch (nm < 0 )
{
    case true:
        Console.WriteLine("Number is negative value.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter your age : ");
byte age1 = Convert.ToByte(Console.ReadLine());

switch (age1 >= 65 )
{
    case true:
        Console.WriteLine("You are eligible for retirement.");
        break;
    default:
        Console.WriteLine("You are not eligible for retirement.");
        break;


}

Console.ReadLine();
Console.Clear();

//================================================================




