using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IF_Else_exercise_2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ahmad";
            Console.ReadLine();

            Console.WriteLine("Take a character input and check if character is C then print ''C#'' otherwise print Invalid Character ");
            char character = Convert.ToChar(Console.ReadLine());
            // C
            if (character == 'C')
            { Console.WriteLine("C#"); }
            else { Console.WriteLine("Invalid Charavter"); }

            //=======================================================

            Console.WriteLine("Take a number and check if number is 7 then print '' seven '' otherwise print Invalid number");
            byte num1 = Convert.ToByte(Console.ReadLine());
            // 7
            if (num1 == 7)
            { Console.WriteLine("Seven"); }
            else { Console.WriteLine("Invalid Number"); }

            //=======================================================


            Console.WriteLine("Take a pie value input and check if value is 3.14 then print '' Correct '' otherwise Invalid Number");
            float num2 = Convert.ToSingle(Console.ReadLine());
            // 3.14
            if (num2 == 3.14F)
            { Console.WriteLine("Correct Value"); }
            else { Console.WriteLine("Invalid Number");}
            //=======================================================

            Console.WriteLine("Take a string input and check if value is one then pring 1 otherwise Invalid Number ");
            string  name= Console.ReadLine();
            // one
            if (name == "one")
            { Console.WriteLine("1"); }
            else { Console.WriteLine("Invalid Name"); }
            //=======================================================

            Console.WriteLine("Take Boolean value input and check if value is true then print Married otherwise Unmarried");
            bool check = Convert.ToBoolean(Console.ReadLine());
            // true
            if (check==true)
            { Console.WriteLine("Married"); }
            else { Console.WriteLine("Unmarried"); }
            //=======================================================

            Console.WriteLine("Take a character input and check if character is P then Print '' PHP '' otherwise Invalid correct");
            char a= Convert.ToChar(Console.ReadLine());
            //p
            if (a == 'p')
            { Console.WriteLine("PHP"); }
            else { Console.WriteLine("Invalid Character"); }
            //=======================================================
            Console.WriteLine("Take a number input and check if is 9 then print Nine otherwise print Invalid Number");
            byte num3=Convert.ToByte(Console.ReadLine());
            // 9 
            if (num3==9)
            { Console.WriteLine("Nine"); }
            else { Console.WriteLine("Invalid Number"); }
            //=======================================================
            Console.WriteLine("Take a floating vlue input and check if value is 6.18 then print ''Correct Value'' otherwise Invalid Number");
            float single = Convert.ToSingle(Console.ReadLine());
            // 6.18
            if (single == 6.18F)
            { Console.WriteLine("Correct Value"); }
            else { Console.WriteLine("Invalid Number"); }
            //=======================================================
            Console.WriteLine("Take boolean value unput and check if true then print Educated otherwise Uneducated");
            bool check1= Convert.ToBoolean(Console.ReadLine());
            // true
            if (check1 == true)
            { Console.WriteLine("Educated"); }
            else { Console.WriteLine("Uneducated"); }
            //=======================================================
            Console.WriteLine("Take a string input and check if value is �ten� then print 10 otherwise Print �Invalid String�");
            string num4=Convert.ToString(Console.ReadLine());
            // ten
            if (num4=="ten")
            { Console.WriteLine("10"); }    
            else { Console.WriteLine("Invalid Number"); }
            //=======================================================

            Console.WriteLine("Take a character input and check if character is M then print MS Office otherwise invalid character");
            char ch1=Convert.ToChar(Console.ReadLine());
            // m
            if (ch1=='m')
            { Console.WriteLine("MS Office"); }
            else { Console.WriteLine("Invalid  Character"); }
            //=======================================================
            Console.WriteLine("Take a number input and check if is 10 then print Ten otherwise invalid character");
            byte num5 = Convert.ToByte(Console.ReadLine());
            // 10
            if (num5 == 10)
            { Console.WriteLine("Ten"); }
            else { Console.WriteLine("Invalid  Number"); }
            //=======================================================
            Console.WriteLine("Take a floating value input and check if value is 9.33 then print Correct Value otherwise print Invalid Value");
            float check2 = Convert.ToSingle(Console.ReadLine());
            // 9.33
            if (check2==9.33F)
            { Console.WriteLine("Correct Value"); }
            else { Console.WriteLine("Invalid  Number"); }
            //=======================================================
            Console.WriteLine("Take Boolean value input and check if value is true then Print Student otherwise print Not a Student");
            bool who = Convert.ToBoolean(Console.ReadLine());
            // true
            if (who == true)
            { Console.WriteLine("Student"); }
            else { Console.WriteLine("Not a Student"); }
            //=======================================================
            Console.WriteLine("Take a string input and check if value is fifteen then print 15 otherwise print Invalid String");
            string numInAlpha = (Console.ReadLine());
            // fifteen
            if (numInAlpha == "fifteen")
            { Console.WriteLine("15"); }
            else { Console.WriteLine("Invalid  string"); }
            //=======================================================
            Console.WriteLine("Take a character input and check if character is J then print Java otherwise Print Invalid Character");
            char ch3 = Convert.ToChar(Console.ReadLine());
            // j
            if (ch3 == 'j')
            { Console.WriteLine("Java"); }
            else { Console.WriteLine("Invalid  Character"); }
            //=======================================================
            Console.WriteLine("Take a number input and check if number is 15 Print Fifteen otherwise Print Invalid Number");
            byte num6 = Convert.ToByte(Console.ReadLine());
            // 15
            if (num6 == 15)
            { Console.WriteLine("Fifteen"); }
            else { Console.WriteLine("Invalid  Number"); }
            //=======================================================
            Console.WriteLine("Take a floating value input and check if value is 10.24 then print Correct Value otherwise Print Invalid Value");
            float check3= Convert.ToSingle(Console.ReadLine());
            // 10.24
            if (check3==10.24F)
            { Console.WriteLine("Correct Value"); }
            else { Console.WriteLine("Invalid  value"); }
            //=======================================================
            Console.WriteLine("Take Boolean value input and check if value is false then Print Unmarried otherwise print Married");
            bool confirm = Convert.ToBoolean(Console.ReadLine());
            // false
            if (confirm == false)
            { Console.WriteLine("Unmarried"); }
            else { Console.WriteLine("Married"); }
            //=======================================================
            Console.WriteLine("Take a string input and check if value is fifty then print 50 otherwise print invalid string");
            string alpha = (Console.ReadLine());
            // fifty
            if (alpha == "fifty")
            { Console.WriteLine("50"); }
            else { Console.WriteLine("Invalid  string"); }
            //=======================================================
            Console.WriteLine("Take a character input and check if character is H then print HTML otherwise print Invalid Character");
            char ch2 = Convert.ToChar(Console.ReadLine());
            // h
            if (ch2 == 'h')
            { Console.WriteLine("HTML"); }
            else { Console.WriteLine("Invalid  Character"); }
            //=======================================================
            Console.WriteLine("Take a number input and check if number is 20 Print Twenty otherwise print Invalid Number");
            byte num7 = Convert.ToByte(Console.ReadLine());
            // 20
            if (num7== 20)
            { Console.WriteLine("Twenty"); }
            else { Console.WriteLine("Invalid  Number"); }
            //=======================================================
            Console.WriteLine("Take a floating value input and check if value is 13.19 then print Correct Value otherwise print Invalid Value");
            float  with = Convert.ToSingle(Console.ReadLine());
            // 13.19
            if (with== 13.19F)
            { Console.WriteLine("Correct Value"); }
            else { Console.WriteLine("Invalid  Value"); }
            //=======================================================
            Console.WriteLine("Take Boolean value input and check if value is true then Print Uneducated otherwise Print Educated");
            bool check_1 = Convert.ToBoolean (Console.ReadLine());
            // true
            if (check_1 == true)
            { Console.WriteLine("Uneducated"); }
            else { Console.WriteLine("Educated"); }
            //=======================================================
            Console.WriteLine("Take Price Input and and check if Price is 100000 then Print You can Buy Dell Laptop Otherwise Print Invalid Amount");
            int amount = Convert.ToInt32(Console.ReadLine());
            // 100000
            if (amount == 100000)
            { Console.WriteLine("You can buy dell laptop "); }
            else { Console.WriteLine("Invalid  Amount"); }
            //=======================================================



            Console.ReadLine();
        }
    }
}
