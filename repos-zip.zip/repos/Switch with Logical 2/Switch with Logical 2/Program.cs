﻿

Console.Write("Enter Urdu marks 50 : ");
byte urdu = Convert.ToByte(Console.ReadLine());

Console.Write("Enter Eng marks 50 : ");
byte eng = Convert.ToByte(Console.ReadLine());

Console.Write("Enter Math marks 50 : ");
byte math = Convert.ToByte(Console.ReadLine());

switch (urdu == 50 && eng == 50 && math == 50)
{
    case true: Console.WriteLine("Well Done.");
        break;
    default:
        Console.WriteLine("Sorry.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================



Console.Write("Enter age 1,2,3,4 : ");
byte age  = Convert.ToByte(Console.ReadLine());

switch (age == 1 || age == 2 || age == 3 || age == 4)
{
    case true: Console.WriteLine("Baby.");
        break;
    default: Console.WriteLine("Invalid.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter age 13 : ");
byte age1  = Convert.ToByte(Console.ReadLine());

switch (age1 == 13)
{
    case true: Console.WriteLine("Toddler.");
        break;
    default: Console.WriteLine("Invalid.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter age 19 : ");
byte age2  = Convert.ToByte(Console.ReadLine());

switch (age2 == 19)
{
    case true: Console.WriteLine("Teenager.");
        break;
    default: Console.WriteLine("Invalid.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================



Console.Write("Enter age 30 : ");
byte age3  = Convert.ToByte(Console.ReadLine());

switch (age3 == 30)
{
    case true: Console.WriteLine("Young Adult.");
        break;
    default: Console.WriteLine("Invalid.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter age 50 : ");
byte age4  = Convert.ToByte(Console.ReadLine());

switch (age4 == 50)
{
    case true: Console.WriteLine("Middle age Adult.");
        break;
    default: Console.WriteLine("Invalid.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter age 60 : ");
byte age5  = Convert.ToByte(Console.ReadLine());

switch (age5 == 60)
{
    case true: Console.WriteLine("Retired.");
        break;
    default: Console.WriteLine("Invalid.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================



Console.Write("Enter age 61 : ");
byte age6  = Convert.ToByte(Console.ReadLine());

switch (age6 == 61)
{
    case true: Console.WriteLine("Elderly.");
        break;
    default: Console.WriteLine("Invalid.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter Experience 10,5 : ");
byte exp = Convert.ToByte(Console.ReadLine());

Console.WriteLine("Enter Gender M or F : ");
char gender = Convert.ToChar(Console.ReadLine());

Console.Write("Enter Master, Graduation : ");
string edu = Console.ReadLine();

switch (exp == 10 && gender == 'M' && edu.ToLower() == "master")
{
    case true:
        Console.WriteLine("Your salary is 50000.");
        break;
}

switch (exp == 10 && gender == 'F' && edu.ToLower() == "master")
{
    case true:
        Console.WriteLine("Your salary is 45000.");
        break;
}

switch (exp == 10 && gender == 'M' && edu.ToLower() == "graduation")
{
    case true:
        Console.WriteLine("Your salary is 40000.");
        break;
}

switch (exp == 10 && gender == 'F' && edu.ToLower() == "graduation")
{
    case true:
        Console.WriteLine("Your salary is 35000.");
        break;
}


switch (exp == 5 && gender == 'M' && edu.ToLower() == "master")
{
    case true:
        Console.WriteLine("Your salary is 30000.");
        break;
}

switch (exp == 5 && gender == 'F' && edu.ToLower() == "master")
{
    case true:
        Console.WriteLine("Your salary is 25000.");
        break;
}

switch (exp == 5 && gender == 'M' && edu.ToLower() == "graduation")
{
    case true:
        Console.WriteLine("Your salary is 20000.");
        break;
}

switch (exp == 5 && gender == 'F' && edu.ToLower() == "graduation")
{
    case true:
        Console.WriteLine("Your salary is 15000.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================








