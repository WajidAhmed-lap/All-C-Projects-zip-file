using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Percentage_find
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ahmed";

            //Console.Write("Please enter bill amount : ");
            //ushort bill = Convert.ToUInt16(Console.ReadLine());
            ////     25000

            //int discount = bill * 10 / 100;
            //Console.WriteLine($"This is your 10% discount amount : {discount}");
            //// 2500

            //int net = bill - discount;
            //Console.WriteLine($"Your Net bill : {net}");
            ////22500



            Console.Write("Enter your earning amount : ");
            int earn = Convert.ToInt32(Console.ReadLine());
            // 500000

            int ali = earn * 35 / 100;
            Console.WriteLine($"Ali 35% amount : {ali}");
            // 175000

            int ahmed = earn * 60 / 100;
            Console.WriteLine($"Ahmed 60% : {ahmed}");
            //300000

            int asif = earn * 5 / 100;
            Console.WriteLine($"Asif 5% : {asif}");



            Console.ReadLine();
        }
    }
}
