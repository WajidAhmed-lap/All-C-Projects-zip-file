using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Table_with_user_data
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ahmed";

            Console.BackgroundColor = ConsoleColor.Red;
            Console.Clear();

            //      Input 
            Console.WriteLine("Enter Month : ");
            string month = Console.ReadLine();
            Console.WriteLine("Name : ");
            string name = Console.ReadLine();
            Console.WriteLine("Father's Name : ");
            string fathersName = Console.ReadLine();
            Console.WriteLine("ID : ");
            byte studentID = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Course : ");
            string course = Console.ReadLine();
            Console.WriteLine("Tution Fee : ");
            short tutionFee = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Computer Fee : ");
            short computerFee = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Registration Fee : ");
            ushort registrationFee = Convert.ToUInt16(Console.ReadLine());
            ushort subTotal = Convert.ToUInt16(tutionFee + computerFee + registrationFee);
            int discount10 = Convert.ToInt32(subTotal * 10 / 100);

            int total = subTotal - discount10;
            Console.Clear();



            //              Body 

            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(50, 5);
            Console.WriteLine("Sir Noman Institute");
            Console.WriteLine("\t\t\t\t\tLatifabad No 4 ");
            Console.WriteLine("\t\t\t\t\tS_I_T_E_ _ HYDERABAD--92---");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\t\t\t\t\t    ---------------");
            Console.WriteLine("\t\t\t\t\t    : Fee Challan :");
            Console.WriteLine("\t\t\t\t\t    ---------------");
            Console.WriteLine($"\tMonth :\t\t\t{month}");
            Console.WriteLine($"\tStudent :\t\t{name}");
            Console.WriteLine($"\tFather's Name :\t\t{fathersName}");
            Console.WriteLine("\tDate Of Addmission :\tSept 1,2023");
            Console.WriteLine($"\tStudent ID : \t\t\t{studentID}");
            Console.WriteLine($"\tCourse : \t\t\t {course}");
            Console.WriteLine("\t---------------------------------------------------------------------------------");
            Console.WriteLine("\t:\t\tFee Detail\t\t:\t               Amount");
            Console.WriteLine("\t---------------------------------------------------------------------------------");
            Console.WriteLine($"\t:      Tution Fee Of Oct203 \t\t:\t               {tutionFee}");
            Console.WriteLine("\t---------------------------------------------------------------------------------");
            Console.WriteLine("\t:      Language / Art Fee of Oct2023    :\t               0");
            Console.WriteLine("\t---------------------------------------------------------------------------------");
            Console.WriteLine($"\t:      Computer Fee of Oct2023          :\t               {computerFee}");
            Console.WriteLine("\t---------------------------------------------------------------------------------");
            Console.WriteLine($"\t:      Registration Fee                 :\t               {registrationFee}");
            Console.WriteLine("\t---------------------------------------------------------------------------------");
            Console.WriteLine("\t:      Arears                           :\t               0");
            Console.WriteLine("\t---------------------------------------------------------------------------------");
            Console.WriteLine($"\t:      Discount                         :\t               {discount10}");
            Console.WriteLine("\t---------------------------------------------------------------------------------");
            Console.WriteLine($"\t:      Total Payble Amount              :\t               {total}");
            Console.WriteLine("\t---------------------------------------------------------------------------------");
            Console.WriteLine("\tDate Of Issue : 01-Oct-2023             Due Date :                 10-Oct-2023.");


            Console.ReadLine();
        }
    }
}
