using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IF_with_Logical_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ahmed";


            Console.Write("Enter your name : ");
            string name = Console.ReadLine();

            Console.Write("Enter your fee : ");
            int fee = Convert. ToInt32(Console.ReadLine());


            if (name == "atif" && fee == 1000)
            { Console.WriteLine("Valid Record."); }

            else { Console.WriteLine("Invalid Record."); }
            Console.ReadLine();
            Console.Clear();



            //========================================================


            Console.Write("Enter your course : ");
            string course = Console.ReadLine();

            Console.Write("Enter your fee : ");
            int fee1 = Convert. ToInt32(Console.ReadLine());


            if (course == "DOT NET" && fee1 >= 5000)
            { Console.WriteLine("Valid Record."); }

            else { Console.WriteLine("Invalid Record."); }
            Console.ReadLine();
            Console.Clear();


            //========================================================

            Console.Write("Enter your course : ");
            string course1 = Console.ReadLine();

            Console.Write("Enter your age : ");
            byte age = Convert.ToByte(Console.ReadLine());


            if (course1 == "DOT NET" && age >= 15)
            { Console.WriteLine("You can enroll."); }

            else { Console.WriteLine("You can't enroll."); }
            Console.ReadLine();
            Console.Clear();

            //========================================================

            Console.Write("Enter your city name : ");
            string city = Console.ReadLine();

            Console.Write("Enter your course : ");
            string course2 = Console.ReadLine();


            if (city == "Hyderabad" && course2 =="DOT NET")
            { Console.WriteLine("Valid Record."); }

            else { Console.WriteLine("Invalid Record."); }
            Console.ReadLine();
            Console.Clear();

            //========================================================

            Console.Write("Enter language character : ");
            char ch = Convert.ToChar(Console.ReadLine());

            if (ch == 'd' || ch == 'D')
            {
                Console.WriteLine("DOT NET.");
            }
            else { Console.WriteLine("Invalid character.");}
               Console.ReadLine();
               Console.Clear();

            //======================================================

            Console.Write("Enter the number : ");
            byte nm = Convert.ToByte(Console.ReadLine());

            if (nm == 1 || nm == 3)
            { Console.WriteLine("Starting positive two ODD numbers"); }

            else { Console.WriteLine("Unknown numbers"); }

            Console.ReadLine();
            Console.Clear();
            //                  ========================================================

            Console.Write("Enter your name : ");
            string name1 = Console.ReadLine();

            Console.Write("Enter your course : ");
            string course3 = Console.ReadLine();

            Console.Write("Enter your age : ");
            byte  age1= Convert.ToByte(Console.ReadLine());

            if (name1 == "asif" && course == "C#" && age1 >= 15)
            { Console.WriteLine("Valid Record."); }
            
            else { Console.WriteLine("Invalid Record."); }

            Console.ReadLine();
            Console.Clear();


            //===================================================

            Console.Write("Enter day : ");
            string day = Console.ReadLine();

            if (day == "Monday" || day == "Tuesday" || day == "Wednesday" ||
                day == "Thursday")
            { Console.WriteLine("Working day."); }
            else { Console.WriteLine("Not a working day."); }




            Console.ReadLine();
        }
    }
}
