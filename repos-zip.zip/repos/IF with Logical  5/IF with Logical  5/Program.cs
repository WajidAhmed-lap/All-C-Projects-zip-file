using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IF_with_Logical__5
{
    internal class Program
    {
        static void Main(string[] args)
        {



            Console.Title = "AHMED";


           //  Q no 1
            Console.WriteLine("                     Q No : 1");


            Console.Write("\n\n\nAre you local : ");
            string resident = Console.ReadLine();

            Console.WriteLine("Enter your age.");
            byte age = Convert.ToByte(Console.ReadLine());




            if (resident == "yes" && age >=20)
            {
                Console.WriteLine("You can vote.");
            
            }

            else { Console.WriteLine("You can not vote."); }

            Console.ReadLine();
            Console.Clear();


            //===========================================================================

        


            //  Q no 2


            Console.WriteLine("                     Q No : 2");


            Console.Write("\n\n\nEnter your Written marks : ");
            byte written = Convert.ToByte(Console.ReadLine());

            Console.WriteLine("Enter your practical marks : ");
            byte practical = Convert.ToByte(Console.ReadLine());




            if (written >= 50  && practical >= 50)
            {
                Console.WriteLine("You are pass.");
            
            }

            else { Console.WriteLine("Sorry,You are fail."); }

            Console.ReadLine();
            Console.Clear();


            //===========================================================================


            //  Q no 3


            Console.WriteLine("                     Q No : 3");


            Console.Write("\n\n\nEnter your number : ");
            short number = Convert.ToInt16(Console.ReadLine());


            if (number >= 1 && number <= 100  )
            {
                Console.WriteLine("Number in range.");
            
            }

            else if (number == 0 || number >= 101)
            { Console.WriteLine("Number in not range."); }

            else if (number < 0 )
            { Console.WriteLine("Number in negative range."); }

            Console.ReadLine();
            Console.Clear();


            //===========================================================================

            //  Q no 4


            Console.WriteLine("                     Q No : 4");


            Console.Write("\n\n\nEnter your science marks : ");
            byte science = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter your math marks : ");
            byte math = Convert.ToByte(Console.ReadLine());


            if (science >= 90 && math >= 90  )
            {
                Console.WriteLine("Student excels in math and science.");
            
            }

            else  
            { Console.WriteLine("Student did not good."); }

            
            Console.ReadLine();
            Console.Clear();


            //===========================================================================



            //  Q no 6


            Console.WriteLine("                     Q No : ");

            
            Console.Write("\n\n\nEnter Water temprature : ");
            sbyte temp = Convert.ToSByte(Console.ReadLine());

            

            if (temp >=0 && temp <= 100 )
            {
                Console.WriteLine("Water is in liquid state.");

            }
            
            else  
            { Console.WriteLine("Water is not in liquid state."); }

            
            Console.ReadLine();
            Console.Clear();


            //===========================================================================


            //  Q no 7


            Console.WriteLine("                     Q No : 7");


            Console.Write("\n\n\nDo we have stock : ");
            string stock = Console.ReadLine();

            Console.Write("Is product on sale : ");
            string sale = Console.ReadLine();


            if (stock == "yes" && sale == "yes")
            {
                Console.WriteLine("Product is available and on sale.");

            }

            else
            { Console.WriteLine("Product is not available or not on sale."); }


            Console.ReadLine();
            Console.Clear();


            //===========================================================================







            Console.ReadLine();

        }
    }
}
