﻿
Console.Title = "AHMED";


Console.Write("Please enter your total amount of bill :  ");
byte amount = Convert.ToByte(Console.ReadLine());

Console.Write("Are you a premium member : ");
string member = Console.ReadLine();

if (amount >= 50 || member == "yes")
{
    Console.WriteLine("You are eligible for free shipping.");
}

else
{
    Console.WriteLine("you are not eligible for free shipping");
}
Console.ReadLine();
Console.Clear();

//====================================================================


Console.Write("Please enter any vowel letter :  ");
char vowel = Convert.ToChar(Console.ReadLine());

if (vowel == 'a' || vowel == 'e' || vowel == 'i' || vowel == 'o' || vowel == 'u')
{
    Console.WriteLine($"This is {vowel} vowel letter");
}

else
{
    Console.WriteLine("This is not vowel letter.");
}

Console.ReadLine();
Console.Clear();

//====================================================================

Console.Write("Please enter your age : ");
byte age = Convert.ToByte(Console.ReadLine());

Console.Write("Enter the number of years worked : ");
byte worked = Convert.ToByte(Console.ReadLine());

if (age >= 55 || worked >= 30)
{
    Console.WriteLine("You are eligible for early retirment.");
}

else
{
    Console.WriteLine("You are not eligible for early retirement.");
}

Console.ReadLine();
Console.Clear();

//===================================================================

Console.WriteLine("Enter your exam score : ");
byte score = Convert.ToByte(Console.ReadLine());

Console.WriteLine("Do you have teacher's recommendation : ");
bool recommend = Convert.ToBoolean(Console.ReadLine());

if (recommend == true || score >= 40)
{
    Console.WriteLine("You have  passed the course.");
}

else
{
    Console.WriteLine("You have not passed the course.");

}

Console.ReadLine();
Console.Clear();

//==============================================================

Console.WriteLine("Enter your GPA : ");
float gpa = Convert.ToSingle(Console.ReadLine());

Console.WriteLine("Are you involved in community service? : ");
bool presence = Convert.ToBoolean(Console.ReadLine());

if (gpa >= 3.5 || presence == true)

{
    Console.WriteLine("Eligible for scolarship.");
}

else
{
    Console.WriteLine("Not eligible for scholarship.");
}

Console.ReadLine();
Console.Clear();


//=====================================================================

Console.WriteLine("Is the product in stock ? : ");
bool stock = Convert.ToBoolean(Console.ReadLine());

Console.Write("Is the product available for pre-order ?");
bool pre = Convert.ToBoolean(Console.ReadLine());

if (stock == true || pre == true)
{
    Console.WriteLine("The product is available for purchase.");
}

else
{

    Console.WriteLine("The product is not available for purchase.");
}

Console.ReadLine();
Console.Clear();


//=====================================================================



Console.Write("Enter your age : ");
byte age1 = Convert.ToByte(Console.ReadLine());

Console.Write("Do you have a student id : ");
bool id = Convert.ToBoolean(Console.ReadLine());

if (age1 >= 60 || id == true)
{
    Console.WriteLine("Eligible for discount.");
}

else
{
    Console.WriteLine("Not eligible for discount.");
}














Console.ReadLine();