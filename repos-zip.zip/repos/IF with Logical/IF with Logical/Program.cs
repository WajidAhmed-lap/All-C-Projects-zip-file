using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IF_with_Logical
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = " AHMED";


            Console.Write("Enter your english marks : ");
            byte engMarks = Convert.ToByte (Console.ReadLine());

            Console.Write("Enter your english marks : ");
            byte urduMarks = Convert.ToByte (Console.ReadLine());

            Console.Write("Enter your english marks : ");
            byte arabicMarks = Convert.ToByte (Console.ReadLine());


            if (engMarks >= 50 && urduMarks >= 50 && arabicMarks >= 50)
            { Console.WriteLine("Well done you have pass. "); }

            else { Console.WriteLine("Sorry you are not pass ."); }

            Console.ReadLine();
            Console.Clear();

            //========================================================


            Console.Write("Enter your age : ");
            byte age = Convert.ToByte (Console.ReadLine());

            if (age >= 1 && age <= 4)
            { Console.WriteLine("Baby"); }

            else { Console.WriteLine("Invalid"); }
            Console.ReadLine();
            Console.Clear();
            //========================================================

            Console.Write("Enter your age again : ");
            byte age1= Convert.ToByte (Console.ReadLine());

            if (age1>=5 && age1<=13)
            { Console.WriteLine("Toddler"); }

            else { Console.WriteLine("Invalid"); }
            Console.ReadLine();
            Console.Clear();


            //======================================================

            Console.Write("Enter age : ");
            byte age2 = Convert.ToByte (Console.ReadLine());

            if (age2 >= 13 && age2 <= 19)
            { Console.WriteLine("Teenager"); }

            else { Console.WriteLine("Invalid"); }
            Console.ReadLine();
            Console.Clear();
            //==================================================


            Console.Write("Enter age : ");
            byte age3 = Convert.ToByte (Console.ReadLine());

            if (age3 >= 20 && age3 <= 30)
            { Console.WriteLine("Young Adult."); }

            else { Console.WriteLine("Invalid."); }
            Console.ReadLine();
            Console.Clear();
            //===============================================

            Console.Write("Enter age : ");
            byte age4 = Convert.ToByte (Console.ReadLine());

            if (age4 >= 31 && age4 <= 50)
            { Console.WriteLine("Middle Age Adult."); }

            else { Console.WriteLine("Invalid."); }
            Console.ReadLine();
            Console.Clear();


            //===============================================================

            Console.Write("Enter age : ");
            byte age5 = Convert.ToByte (Console.ReadLine());

            if (age5 >= 51 && age5 <= 60)
            { Console.WriteLine("Retired."); }

            else { Console.WriteLine("Invalid."); }
            Console.ReadLine();
            Console.Clear();

            //====================================================



            Console.Write("Enter age : ");
            byte age6 = Convert.ToByte (Console.ReadLine());

            if (age6 >= 51 )
            { Console.WriteLine("Elderly."); }

            Console.ReadLine();
            Console.Clear();


            //===========================================================


            Console.Write("Enter your Gender : ");
            string gender = Console.ReadLine();

            Console.Write("Enter Your experience in number : ");
            byte exp= Convert.ToByte (Console.ReadLine());

            Console.Write("Enter your qualification : ");
            string qualification = Console.ReadLine();

            if (gender == "Male" && exp>=10 && qualification=="Master")
            { Console.WriteLine("Salary is 50000."); }

            else if (gender == "Female" && exp >= 10 && qualification == "Master")
            { Console.WriteLine("Salary is 45000."); }

            else if (gender == "Male" && exp>=10 && qualification=="Graduation")
            { Console.WriteLine("Salary is 40000."); }

            else if (gender == "Female" && exp >= 10 && qualification == "Graduation")
            { Console.WriteLine("Salary is 35000."); }

            else if (gender == "Male" && exp>=5 && qualification=="Master")
            { Console.WriteLine("Salary is 30000."); }

            else if (gender == "Female" && exp >= 5 && qualification == "Master")
            { Console.WriteLine("Salary is 25000."); }

            else if (gender == "Male" && exp>=5 && qualification=="Graduation")
            { Console.WriteLine("Salary is 30000."); }

            else if (gender == "Female" && exp >= 5 && qualification == "Graduation")
            { Console.WriteLine("Salary is 15000."); }

            else if (gender == "Female" && exp >= 10 && qualification == "Graduation")
            { Console.WriteLine("Salary is 35000."); }

           Console.ReadLine();
           Console.Clear();



           //======================================================================

           Console.Write("Enter your salary : ");
           int salary = Convert.ToInt32 (Console.ReadLine());

           Console.Write("Enter your Education : ");
           string edu = Console.ReadLine();

           if (salary>50000 && edu=="Master")
           { Console.WriteLine("Your bonus is 10000."); }

           else if (salary>50000 && edu=="Graduation")
           { Console.WriteLine("Your bonus is 8000."); }

           else if (salary>30000 && edu=="Master")
           { Console.WriteLine("Your bonus is 7000."); }

           else if (salary>30000 && edu=="Graduation")
           { Console.WriteLine("Your bonus is 5000."); }


           Console.ReadLine();
           Console.Clear();

           //===================================================

           Console.Write("Enter username : ");
           string userName = Console.ReadLine();

           Console.Write("Enter your password : ");
           string password = Console.ReadLine();

           if (userName== "admin" && password== "admin")
           { Console.WriteLine("Welcome."); }

           else if (userName== "admin" && password!= "admin")
           { Console.WriteLine("Invalid Password."); }

          else  if (userName != "admin" && password == "admin")
           { Console.WriteLine("Invalid username."); }

           else if (userName!= "admin" && password!= "admin")
           { Console.WriteLine("Invalid username and password."); }

           Console.ReadLine();
           Console.Clear();

            //======================================================


            




            Console.Write("Enter product name : ");
            string product = Console.ReadLine();

            Console.Write("Quantity : ");
            byte quantity = Convert.ToByte(Console.ReadLine());

            if ((product == "keyboard" || product == "Keyboard" || product == "KEYBOARD")
                && (quantity >= 1 && quantity <= 5))
            {
                Console.WriteLine("Available");
            }

            else if ((product == "mouse" || product == "Mouse" || product == "MOUSE")
                && (quantity >= 1 && quantity <= 10))
            {
                Console.WriteLine("Available");
            }

            else if ((product == "ram" || product == "Ram" || product == "RAM")
                && (quantity >= 1 && quantity <= 3))
            {
                Console.WriteLine("Available");
            }

            else
            {
                Console.WriteLine("Not Available");
            }

            Console.ReadLine();




















            Console.ReadLine();
        }
    }
}
