using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IF_with_Relational__3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = " Ahmed";


            Console.Write("Enter marks : ");
            byte mark = Convert.ToByte (Console.ReadLine());

            if (mark <30  )
            { Console.WriteLine("Student is required to retake the exam."); }
            Console.ReadLine();
            Console.Clear();

            //              ======================================================================

            Console.Write("I'm checking the tempereture.");
            sbyte temp = Convert.ToSByte (Console.ReadLine());

            if (temp < 15 )
            { Console.WriteLine("Wear a jacket."); }

            Console.ReadLine();
            Console.Clear();

            //=====================================================

            Console.WriteLine("Enter any number less than 50 ");
            byte nm= Convert.ToByte (Console.ReadLine());

            if (nm<50)
            { Console.WriteLine("Inventory is below minimum threshold."); }

            Console.ReadLine();
            Console.Clear();

            //==========================================================

            Console.WriteLine("Enter your book days ");
            byte book = Convert.ToByte (Console.ReadLine());

            if (book<=7)
            { Console.WriteLine("Fine No charge ."); }

            else { Console.WriteLine("Fine has applied."); }

            Console.ReadLine();
            Console.Clear();


            //  ===================================================

            Console.Write("Enter your parsal weight.");
            float weight = Convert.ToSingle (Console.ReadLine());

            if (weight <= 1000.00)
            { Console.WriteLine("Eligible for light weight shipping"); }

            Console.ReadLine();
            Console.Clear();

            //==================================================

            Console.Write("Enter your travel distance . ");
            float km= Convert.ToSingle (Console.ReadLine());

            if (km<=100)
            { Console.WriteLine("Short distance travel."); }

            Console.ReadLine();
            Console.Clear();

            //==========================================================

            Console.Write("Enter your membership months.");
            byte mem= Convert.ToByte (Console.ReadLine());

            if(mem<=3)
            { Console.WriteLine("Ineligible for loyalty discount."); }

            Console.ReadLine();
            Console.Clear();

            //===========================================================

            Console.Write("Book price.");
            byte price = Convert.ToByte (Console.ReadLine());

            if (price <= 20)
            { Console.WriteLine("Eligible for student discount"); }

            Console.ReadLine();
            Console.Clear();

            //======================================================

            Console.Write("Enter student attendance .");
            byte att= Convert.ToByte (Console.ReadLine());

            if (att<=75)
            { Console.WriteLine("Warning low attendance"); }

            Console.ReadLine();
            Console.Clear();

            //=========================================================

            Console.Write("Enter your child's age.");
            byte age = Convert.ToByte (Console.ReadLine());

            if (age <12)
            { Console.WriteLine("Not eligible for the roller coaster"); }






            Console.ReadLine();
        }
    }
}
