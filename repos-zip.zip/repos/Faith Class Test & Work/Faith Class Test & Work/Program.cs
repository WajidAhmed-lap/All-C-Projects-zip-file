using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Faith_Class_Test___Work
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ahmad";

            //          Question No : 1 

            Console.WriteLine("Question No : 1 ");

            Console.Write("Enter your identity : ");
            string identity = Console.ReadLine();
            // user 

            if (identity == "user")
                Console.WriteLine("Hi User ");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            Console.Title = "Ahmad";

            //          Question No : 2 

            Console.WriteLine("Question No : 2 ");

            Console.Write("Enter your Grade  : ");
             char  grade = Convert.ToChar(Console.ReadLine());
            // A

            if (grade == 'A')
                Console.WriteLine("A+ ");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            Console.Title = "Ahmad";

            //          Question No : 3 

            Console.WriteLine("Question No : 3 ");

            Console.Write("Enter your Integer : ");
            byte num = Convert.ToByte(Console.ReadLine());
            // 10

            if (num== 10)
                Console.WriteLine("Perfect Ten ");
            Console.ReadLine();
            Console.Clear();

            //==================================================
            Console.Title = "Ahmad";

            //          Question No : 4 

            Console.WriteLine("Question No : 4 ");

            Console.Write("Are you guest  : ");
            string guest = Console.ReadLine();
            // guest

            if (guest  == "guest")
                Console.WriteLine("Welcome Guest");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            Console.Title = "Ahmad";

            //          Question No : 5 

            Console.WriteLine("Question No : 5 ");

            Console.Write("Enter the last letter of Alpha : ");
            char last  = Convert.ToChar(Console.ReadLine());
            // Z

            if (last== 'Z')
                Console.WriteLine("Yes this is the last letter of Alpha ");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 6

            Console.WriteLine("Question No : 6 ");

            Console.Write("Enter another digit : ");
            byte another = Convert.ToByte(Console.ReadLine());
            // 5

            if (another== 5)
                Console.WriteLine("High Five");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 7 

            Console.WriteLine("Question No : 7 ");

            Console.Write("Enter the code : ");
            string code = Console.ReadLine();
            // admin

            if (code== "admin")
                Console.WriteLine("Access granted ");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 8

            Console.WriteLine("Question No : 8 ");

            Console.Write("Enter the sign : ");
            char sign= Convert.ToChar(Console.ReadLine());
            // X

            if (sign == 'X')
                Console.WriteLine("X marks the spot ");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 9

            Console.WriteLine("Question No : 9 ");

            Console.Write("What's your post : ");
            string post = Console.ReadLine();
            // manager

            if (post == "manager")
                Console.WriteLine("Manager access granted ");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 10 

            Console.WriteLine("Question No : 10 ");

            Console.Write("Who are you : ");
            char who = Convert.ToChar(Console.ReadLine());
            // B

            if (who == 'B')
                Console.WriteLine("Bravo!");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 11 

            Console.WriteLine("Question No : 11 ");

            Console.Write("How aged you ] : ");
            byte age = Convert.ToByte(Console.ReadLine());
            // 20

            if (age == 20)
                Console.WriteLine("You are twenties!");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 12

            Console.WriteLine("Question No : 12 ");

            Console.Write("SMS : ");
            string sms = Console.ReadLine();
            // hi

            if (sms == "hi")
                Console.WriteLine("Hi there");
            Console.ReadLine();
            Console.Clear();

            //==================================================
            //          Question No : 13

            Console.WriteLine("Question No : 13");

            Console.Write("Which animal names start with D : ");
            char animal= Convert.ToChar(Console.ReadLine());
            // Dog

            if (animal== 'D')
                Console.WriteLine("D for Dog!");
            Console.ReadLine();
            Console.Clear();

            //==================================================
            
            //          Question No : 14

            Console.WriteLine("Question No : 14 ");

            Console.Write("What's your lucky number : ");
            byte lucky = Convert.ToByte(Console.ReadLine());
            // 7

            if (lucky  == 7)
                Console.WriteLine("Lucky number ");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 15

            Console.WriteLine("Question No : 15 ");

            Console.Write("Are you affirmative  : ");
            string areYouOkay= Console.ReadLine();
            // yes

            if (areYouOkay== "yes")
                Console.WriteLine("Affirmative ");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 16

            Console.WriteLine("Question No : 16");

            Console.Write("What's your situation  : ");
            char situation= Convert.ToChar(Console.ReadLine());
            // E

            if (situation == 'E')
                Console.WriteLine("Excellent");
            Console.ReadLine();
            Console.Clear();

            //==================================================



            //          Question No : 17

            Console.WriteLine("Question No : 17");

            Console.Write("Enter any integer : ");
            byte number= Convert.ToByte(Console.ReadLine());
            // 100

            if (number == 100)
                Console.WriteLine("Century");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 18

            Console.WriteLine("Question No : 18 ");

            Console.Write("Who are you : ");
            string checking = Console.ReadLine();
            // friend

            if (checking == "friend")
                Console.WriteLine("Hi Friend");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 19

            Console.WriteLine("Question No : 19 ");

            Console.Write("Enter char : ");
            char feeling = Convert.ToChar(Console.ReadLine());
            // F

            if (feeling == 'F')
                Console.WriteLine("Fabulous");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 20

            Console.WriteLine("Question No : 20 ");

            Console.Write("Enter your run: ");
            byte run= Convert.ToByte(Console.ReadLine());
            // 50

            if (run == 50)
                Console.WriteLine("Half century");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 21

            Console.WriteLine("Question No : 21 ");

            Console.Write("Tell me who are Teacher or Student : ");
            string tos =Console.ReadLine();
            // teacher

            if (tos =="teacher")
                Console.WriteLine("Hi Teacher");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 22

            Console.WriteLine("Question No : 22 ");

            Console.Write("Tell me something about your  health : ");
            string hmmm = Console.ReadLine();
            // G

            if (hmmm == "G")
                Console.WriteLine("Good going");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 23

            Console.WriteLine("Question No : 23 ");

            Console.Write("Enter your number: ");
            byte digit = Convert.ToByte(Console.ReadLine());
            // 3

            if (digit == 3)
                Console.WriteLine("Three's a charm");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 24

            Console.WriteLine("Question No : 24 ");

            Console.Write("What time is it now : ");
            string time = Console.ReadLine();
            // morning

            if (time == "morning")
                Console.WriteLine("Good morning");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 25

            Console.WriteLine("Question No : 25 ");

            Console.Write("What are feeling : ");
            char feels = Convert.ToChar(Console.ReadLine());
            // H

            if (feels == 'H')
                Console.WriteLine("Hoooray");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 26

            Console.WriteLine("Question No : 26 ");

            Console.Write("Enter your record : ");
            byte record = Convert.ToByte(Console.ReadLine());
            // 25

            if (record == 25)
                Console.WriteLine("Quarter of a century ");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 27

            Console.WriteLine("Question No : 27 ");

            Console.Write("We'll meet again : ");
            string say = Console.ReadLine();
            // goodbye

            if (say == "goodbye")
                Console.WriteLine("See you soon");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 28

            Console.WriteLine("Question No : 28 ");

            Console.Write("Write Impressive : ");
            char cmd= Convert.ToChar(Console.ReadLine());
            // I

            if (cmd == 'I')
                Console.WriteLine("Impressive");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 29

            Console.WriteLine("Question No : 29 ");

            Console.Write("Enter your new run : ");
            byte newRun = Convert.ToByte(Console.ReadLine());
            // 99

            if (newRun == 99)
                Console.WriteLine("Almost a hundred");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 30

            Console.WriteLine("Question No : 30 ");

            Console.Write("What's your position  : ");
            string position = Console.ReadLine();
            // admin

            if (position == "admin")
                Console.WriteLine("Administrator access granted");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 31

            Console.WriteLine("Question No : 31 ");

            Console.Write("What you wanna do : ");
            char jump = Convert.ToChar(Console.ReadLine());
            // J

            if (jump == 'J')
                Console.WriteLine("Jump for joy ");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 32

            Console.WriteLine("Question No : 32 ");

            Console.Write("Write 1  : ");
            byte translater = Convert.ToByte(Console.ReadLine());
            // 1

            if (translater == 1)
                Console.WriteLine("Number one");
            Console.ReadLine();
            Console.Clear();

            //==================================================



            //          Question No : 33

            Console.WriteLine("Question No : 33 ");

            Console.Write("Enter night : ");
            string telling=Console.ReadLine();
            // night

            if (telling == "night")
                Console.WriteLine("Good night");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 34

            Console.WriteLine("Question No : 34 ");

            Console.Write("What are you wanting to do  : ");
            char countinue= Convert.ToChar(Console.ReadLine());
            // K

            if (countinue == 'K')
                Console.WriteLine("Keep going");
            Console.ReadLine();
            Console.Clear();

            //==================================================


            //          Question No : 35

            Console.WriteLine("Question No : 35 ");

            Console.Write("Enter your age : ");
            byte ageCheck = Convert.ToByte(Console.ReadLine());
            // 18

            if (ageCheck == 18)
                Console.WriteLine("You're an adult now");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 36

            Console.WriteLine("Question No : 36 ");

            Console.Write("What's your professon : ");
            string aboutHim = Console.ReadLine();
            // developer

            if (aboutHim == "developer")
                Console.WriteLine("Welcome Developer");
            Console.ReadLine();
            Console.Clear();

            //==================================================



            //          Question No : 37

            Console.WriteLine("Question No : 37 ");

            Console.Write("Enter about yours : ");
            char lovely= Convert.ToChar(Console.ReadLine());
            // L

            if (lovely == 'L')
                Console.WriteLine("Lovely");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 38

            Console.WriteLine("Question No : 38 ");

            Console.Write("Enter digit i'll tell you : ");
            byte decades= Convert.ToByte(Console.ReadLine());
            // 30

            if (decades == 30)
                Console.WriteLine("Three decades");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 39

            Console.WriteLine("Question No : 39 ");

            Console.Write("Enter your command: ");
            string exit= Console.ReadLine();
            // exit

            if (exit == "exit")
                Console.WriteLine("Exiting program.........");
            Console.ReadLine();
            Console.Clear();

            //==================================================

            //          Question No : 40

            Console.WriteLine("Question No : 40 ");

            Console.Write("How am i feeling  : ");
            char awesome= Convert.ToChar(Console.ReadLine());
            // M

            if (awesome == 'M')
                Console.WriteLine("Marvelous");
            Console.ReadLine();
            Console.Clear();













            Console.ReadLine();
        }
    }
}
