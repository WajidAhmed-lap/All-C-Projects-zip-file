﻿

Console.Title = "AHMED";

Console.Write("Enter atif : ");
string name  = Console.ReadLine();

Console.WriteLine("Enter 1000 : ");
short fee = Convert.ToInt16(Console.ReadLine());    

switch (name == "atif" && fee == 1000 )
{
    case true:
        Console.WriteLine("Valid record.");
        break;
    default:
        Console.WriteLine("Invalid record.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter dot net : ");
string course  = Console.ReadLine();

Console.WriteLine("Enter 5000 : ");
short fee1 = Convert.ToInt16(Console.ReadLine());    

switch (course == "dot net" && fee1 == 5000 )
{
    case true:
        Console.WriteLine("Valid record.");
        break;
    default:
        Console.WriteLine("Invalid record.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter dot net : ");
string course1  = Console.ReadLine();

Console.WriteLine("Enter 15 : ");
byte  age = Convert.ToByte(Console.ReadLine());    

switch (course1 == "dot net" && age == 15 )
{
    case true:
        Console.WriteLine("You can enroll.");
        break;
    default:
        Console.WriteLine("You can not enroll.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================



Console.Write("Enter dot net : ");
string course2  = Console.ReadLine();

Console.WriteLine("Enter hyderabad : ");
string city  = Console.ReadLine();    

switch (course2 == "dot net" && city == "hyderabad" )
{
    case true:
        Console.WriteLine("Valid record.");
        break;
    default:
        Console.WriteLine("Invalid record.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter d or D : ");
char ch  = Convert.ToChar(Console.ReadLine());


switch (ch == 'd' || ch == 'D' )
{
    case true:
        Console.WriteLine("Dot Net.");
        break;
    default:
        Console.WriteLine("Invalid character.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter 1 or 3 : ");
byte odd  = Convert.ToByte(Console.ReadLine());


switch (odd == 1 || odd == 3 )
{
    case true:
        Console.WriteLine("Starting  positive two odd numbers.");
        break;
    default:
        Console.WriteLine("Unknown numbers.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter dot net or Dot Net : ");
string course3  = Console.ReadLine();


switch (course3 == "Dot Net" || course3 == "dot net" )
{
    case true:
        Console.WriteLine("Valid course.");
        break;
    default:
        Console.WriteLine("Invalid course.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter HYDERABAD,Hyd,Hyderabad : ");
string city1  = Console.ReadLine();


switch (city1 == "Hyderabad" || city1 == "HYDERABAD" || city1 == "Hyd")
{
    case true:
        Console.WriteLine("Valid city name.");
        break;
    default:
        Console.WriteLine("Invalid city name.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter C#,Microsoft,Visual : ");
string course4  = Console.ReadLine();


switch (course4 == "C#" || course4 == "Microsoft" || course4 == "Visual")
{
    case true:
        Console.WriteLine("Valid course.");
        break;
    default:
        Console.WriteLine("Invalid course.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter 1,3,5,7 : ");
byte odd1  = Convert.ToByte(Console.ReadLine());


switch (odd1 == 1 || odd1 == 3 || odd1 == 5 || odd1 == 7)
{
    case true:
        Console.WriteLine("ODD number.");
        break;
    default:
        Console.WriteLine("Unkown number.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter asif : ");
string name1 = Console.ReadLine();

Console.Write("Enter C# : ");
string check = Console.ReadLine();

Console.Write("Enter 15 : ");
byte age1 = Convert.ToByte(Console.ReadLine());

switch (name1 == "asif" && check == "C#" && age1 == 15 )
{
    case true: Console.WriteLine("Valid record.");
        break;
    default: Console.WriteLine("Invalid record.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================



Console.Write("Enter Hyderabad : ");
string city2 = Console.ReadLine();

Console.Write("Enter MBA : ");
string qualification = Console.ReadLine();

Console.Write("Enter 20 : ");
byte age2 = Convert.ToByte(Console.ReadLine());

switch (city2 == "Hyderabad" && qualification == "MBA" && age2 == 20 )
{
    case true: Console.WriteLine("You can join.");
        break;
        default: Console.WriteLine("You can not join.");
        break;
}

   
Console.ReadLine();
Console.Clear();

//================================================================



Console.Write("Enter C# : ");
string check2 = Console.ReadLine();

Console.Write("Enter 4000 : ");
short feee = Convert.ToInt16(Console.ReadLine());

switch (check2 == "C#" && feee == 4000 )
{
    case true: Console.WriteLine("Valid record.");
        break;
        default: Console.WriteLine("Invalid record.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter admin,Admin : ");
string username =  Console.ReadLine();

Console.Write("Enter admin : ");
string password = Console.ReadLine();

switch (username == "admin" || username == "Admin" && password == "admin" )
{
    case true: Console.WriteLine("Welcome.");
        break;
        default: Console.WriteLine("Sorry.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================








