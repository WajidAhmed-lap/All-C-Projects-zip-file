﻿

Console.Title = "AHMED";

Console.Write("Enter A,B,C,D : ");
char ch = Convert.ToChar(Console.ReadLine());

switch (ch)
{
    case 'a':
        Console.WriteLine("Apple.");
        break;

    case 'b':
        Console.WriteLine("Banana.");
        break;

        case 'c': Console.WriteLine("Cherry.");
        break;

    case 'd':
        Console.WriteLine("Date.");
        break;

    default:
        Console.WriteLine("Wrong.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter E,F,G,H : ");
char ch1 = Convert.ToChar(Console.ReadLine());

switch (ch1)
{
    case 'e':
        Console.WriteLine("Elephant.");
        break;

    case 'f':
        Console.WriteLine("frog.");
        break;

        case 'g': Console.WriteLine("Giraffe.");
        break;

    case 'h':
        Console.WriteLine("Hippo.");
        break;

    default:
        Console.WriteLine("Wrong.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter 10,20,30,40 : ");
byte num = Convert.ToByte(Console.ReadLine());

switch (num)
{
    case 10:
        Console.WriteLine("Ten.");
        break;
        case 20:
        Console.WriteLine("Twenty.");
        break;
        case 30:
        Console.WriteLine("Thirty");
        break;
        case 40:
        Console.WriteLine("Fourty");
        break;

    default:
        Console.WriteLine("Wrong number.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter 100,200,300,400 : ");
short num1= Convert.ToInt16(Console.ReadLine());

switch (num1)
{
    case 100:
        Console.WriteLine("Hundred.");
        break;
        case 200:
        Console.WriteLine("Two Hundred.");
        break;
        case 300:
        Console.WriteLine("Three Hundred.");
        break;
        case 400:
        Console.WriteLine("Four Hundred.");
        break;

    default:
        Console.WriteLine("Wrong number.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter dog,rose,apple,carrot : ");
string check = Console.ReadLine();

switch (check)
{
    case "dog":
        Console.WriteLine("Animal.");
        break;
    case "rose":
        Console.WriteLine("Flower.");
        break;
    case "apple":
        Console.WriteLine("Fruit.");
        break;
    case "carrot":
        Console.WriteLine("Vegetable.");
        break;

    default:
        Console.WriteLine("Wrong command.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter something red,round,sweet,soft : ");
string shape = Console.ReadLine();

switch (shape)
{
    case "red":
        Console.WriteLine("Colour.");
        break;
    case "round":
        Console.WriteLine("Shape.");
        break;
    case "Sweet":
        Console.WriteLine("Taste.");
        break;
    case "soft":
        Console.WriteLine("Texture.");
        break;

    default:
        Console.WriteLine("Wrong command.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter j,f,m,a : ");
char ch2 = Convert.ToChar(Console.ReadLine());

switch (ch2)
{
    case 'j':
        Console.WriteLine("January.");
        break;

    case 'f':
        Console.WriteLine("February.");
        break;

    case 'm':
        Console.WriteLine("March.");
        break;

    case 'a':
        Console.WriteLine("April.");
        break;

    default:
        Console.WriteLine("Wrong.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================


