using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ascii_Code
{
    internal class Program
    {
        static void Main(string[] args)
        {



            // Q No : 1
            // Write a program that takes input and prints its ASCII code.

            /* Console.Write("Enter any character : ");
             char ch1 = Convert.ToChar(Console.ReadLine());
             //     A

             int asciicode1 = Convert.ToInt32(ch1);
             //     A ========>  65 
             Console.Write($"This is you character ascii code : {asciicode1}");

             Console.WriteLine("=========================================================");


             Console.Write("Enter any character : ");
             char ch2 = Convert.ToChar(Console.ReadLine());
             //     E

             int asciicode2 = Convert.ToInt32(ch2);
             //     E ========>  69 
             Console.Write($"This is you character ascii code : {asciicode2}");

             Console.WriteLine("=========================================================");


             Console.Write("Enter any character : ");
             char ch3 = Convert.ToChar(Console.ReadLine());
             //     G

             int asciicode3 = Convert.ToInt32(ch3);
             //     G ========>  71 
             Console.Write($"This is you character ascii code : {asciicode3}");

             Console.Write("=========================================================");



                                             //  Q No : 2 

             // Write a program that takes an ASCII code as input and prints its corresponding character 


             Console.Write("Enter an ASCII code : ");
             byte asciicode4 = Convert.ToByte(Console.ReadLine());

             //  65 

             char ch4 = Convert.ToChar(asciicode4);
             //    65  ===========>  A

             Console.WriteLine($"This is your character : {ch4}");

             Console.WriteLine("===========================================");

             Console.Write("Enter an ASCII code : ");
             byte asciicode5 = Convert.ToByte(Console.ReadLine());

             //  70 

             char ch5 = Convert.ToChar(asciicode5);
             //    70  ===========>  F

             Console.WriteLine($"This is your character : {ch5}");

             Console.WriteLine("===========================================");

             Console.Write("Enter an ASCII code : ");
             byte asciicode6 = Convert.ToByte(Console.ReadLine());

             //  88 

             char ch6 = Convert.ToChar(asciicode6);
             //    88  ===========>  X

             Console.WriteLine($"This is your character : {ch6}");

             Console.WriteLine("===========================================");



            //  Q No : 3 

            //  Wrote a program that takes a character as input and prints its next character 

            Console.Write("Enter a character : ");
            char ch7 = Convert.ToChar(Console.ReadLine());
            //   A  

            byte asciicode7 = Convert.ToByte(ch7);
            //  65

            Console.WriteLine(ch7);

            asciicode7++;
            
            //      66  ============>  B

            char ch8 = Convert.ToChar(asciicode7);
            Console.WriteLine(ch8);
            Console.WriteLine("==========================================");


            Console.Write("Enter a character :  ");
            char ch9 = Convert.ToChar(Console.ReadLine());
            //   D  

            byte asciicode9= Convert.ToByte(ch9);
            //  68

            char nextch = Convert.ToChar(++asciicode9);
            //    68 + 1 = 69 
            //    E

            Console.WriteLine(ch9);
            Console.WriteLine(nextch);
            Console.WriteLine("===========================================");

            Console.Write("Enter a character : ");
            char ch10 = Convert.ToChar(Console.ReadLine());
            //  X   

            byte asciicode10= Convert.ToByte(ch10);
            //   88 

            byte nextasciicode = Convert.ToByte(asciicode10 + 1);
            //      89   
             
            char ch11 = Convert.ToChar(nextasciicode);

            Console.WriteLine(ch10);
            Console.WriteLine(ch11);
            Console.WriteLine("===========================================");*/


            //              Q No : 4

            //  Write a program that takes a character as input and print its previous character.

            Console.Write("Enter a character : ");
            char ch12 = Convert.ToChar(Console.ReadLine());
            //  B 

            byte ascii = Convert.ToByte(ch12);
            //      66

            --ascii;

            char preCharacter = Convert.ToChar(ascii);
            //  65 ==========>  A

            Console.WriteLine(ch12);
            Console.WriteLine(preCharacter);

            Console.WriteLine("==============================================");

            Console.Write("Enter a character : ");
            char ch13 = Convert.ToChar(Console.ReadLine());
            // D

            byte asciicode11= Convert.ToByte(ch13);
            //  68

            asciicode11--;
            //  67

            char preCh= Convert.ToChar(asciicode11);
            //  68 - 1 = 67
            //              C
            Console.WriteLine(ch13);
            Console.WriteLine(preCh);
            Console.WriteLine("============================================");

            Console.Write("Enter a character : ");
            char ch14= Convert.ToChar(Console.ReadLine());
            //    Z  

            byte asciiCode= Convert.ToByte(ch14);
            //  90

            char preCh1 =Convert.ToChar(--asciiCode);

            Console.WriteLine(ch14);
            Console.WriteLine(preCh1);






            Console.ReadLine();
        }
    }
}
