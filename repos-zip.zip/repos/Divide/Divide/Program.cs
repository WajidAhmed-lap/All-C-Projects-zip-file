using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Divide
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine(3/3);
            //   1
            Console.WriteLine(6/2.0);
            //   3
            Console.WriteLine(3/3.0);
            //   1
            Console.WriteLine(10/3);
            //   3
            Console.WriteLine(10.0/3);
            //   3.33
            Console.WriteLine(8/3.0);
            //   2.667
            Console.WriteLine(10.0/2.0);
            //   5
            Console.WriteLine(5.0/2.0);
            //   2.5
            Console.WriteLine(20/10.0);
            //   2
            Console.WriteLine(21.0/7.0);
            //   3
            Console.WriteLine(15/3);
            //   5
            Console.WriteLine(15.0/3.0);
            //   5
            Console.WriteLine(15.0/3);
            //   5
            Console.WriteLine(15/3.0);
            //   5
            Console.WriteLine(9/2);
            //   4
            Console.WriteLine(9.0/2);
            //   4.5
            Console.WriteLine(9/2.0);
            //   4.5
            Console.WriteLine(9.0/2.0);
            //   4.5
            Console.WriteLine(17/5);
            //   3
            Console.WriteLine(17.0/5);
            //   3.4
            Console.WriteLine(17.0/5.0);
            //   3.4




            Console.ReadLine();
        }
    }
}
