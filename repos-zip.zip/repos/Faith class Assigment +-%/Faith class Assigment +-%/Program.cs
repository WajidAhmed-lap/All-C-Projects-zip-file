using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Faith_class_Assigment____
{
    internal class Program
    {
        static void Main(string[] args)
        {



            Console.Title = "Ahmed";

            /*Console.Write("Enter yout item One price : ");
             int one = Convert.ToInt32(Console.ReadLine());
             //      10000

             Console.Write("Enter Second item price : ");
             int two = Convert.ToInt32(Console.ReadLine());
             //      25000

             int subTotal = one + two; 
             Console.WriteLine("This is your total bill : {0:C0}",subTotal);
             //      35000

             int salesTax = subTotal * 10 / 100;
             Console.WriteLine("This is your 10% Tax amout : {0}",salesTax);
             //         35000 * 10% ===>   3500
             int total = salesTax + subTotal;
             Console.WriteLine("This is your total bill : {0:C0}",total);

            




            Console.Write("Enter total distance ( in km ) : ");
            int distance = Convert.ToInt32(Console.ReadLine());
            //      200

            Console.Write("Enter fuel efficiency ( km per litter ) : ");
             int litter = Convert.ToInt32(Console.ReadLine());
            //   25

            int needed = distance / litter;
            //              200   / 25 ===> 8

            Console.WriteLine("Fuel needed for this trip : {0}",needed);








            Console.Write("Enter bill amount : ");
            int billAmount = Convert.ToInt32(Console.ReadLine());
            // 20000

            Console.Write("Enter tip percentage : ");
            float percentage = Convert.ToSingle(Console.ReadLine());
            // 2.5 

            double tip = billAmount * 2.5 / 100;
            Console.WriteLine("Your tip amount : {0:C0}",tip);
            //      500
            double totalBill = billAmount + tip;
            Console.WriteLine("Total amount to be paid : {0:C0}",totalBill);










            Console.Write("Enter Score for 1 Match : ");
            int match1 = Convert.ToInt32(Console.ReadLine());
            //      110

            Console.Write("Enter Score for 2 Match : ");
            int match2 = Convert.ToInt32(Console.ReadLine());
            //      67

            Console.Write("Enter Score for 3 Match : ");
            int match3 = Convert.ToInt32(Console.ReadLine());
            //  80

            int total = match1 + match2 + match3;

            int  ave = total / 3;
            Console.WriteLine($"Average Score : {ave:F}");








            Console.Write("Enter hourly wage : ");
            int hourlyWage = Convert.ToInt32(Console.ReadLine());
            // 800

            Console.Write("Enter working hours : ");
            int workingHours = Convert.ToInt32(Console.ReadLine());
            //   100

            int total = hourlyWage * workingHours;
            Console.WriteLine("Your amount is : {0:C}",total);
            //    800  *  100  ========>  80000








            Console.Write("Enter your annual salary : ");
            int annual = Convert.ToInt32(Console.ReadLine());
            //==================>  200000

            double daily = annual / 365;
            double weekly = daily * 7;
            double monthly = daily* 30;
            Console.WriteLine("This is your monthly : {0:C}", monthly);
            Console.WriteLine($"Weekly : {weekly:C}");
            Console.WriteLine("Daily : {0:C}",daily);








            Console.Write("Fix price of Each ticket : 600");
            short fix = 600;

            Console.WriteLine("How many you wanna buy : ");
            int t1 = Convert.ToInt32(Console.ReadLine());
            //=========>  3
            int total1 = t1 * fix;
            Console.WriteLine($"Total cost of 3 tickets : {total1:C}");
            //========>    3 * 600 =1800
        

            Console.WriteLine("How many you wanna buy : ");
            int t2 = Convert.ToInt32(Console.ReadLine());
            //=========>  2
            int total2 = t2 * fix;
            Console.WriteLine($"Total cost of 2 tickets : {total2:C}");
            //========>2 * 600   =1200
            Console.WriteLine("How many you wanna buy : ");
            int t3 = Convert.ToInt32(Console.ReadLine());
            //=========>  5
            int total3 = t3 * fix;
            Console.WriteLine($"Total cost of 5 tickets : {total3:C}");
            //========>    5 * 600 =3000









            Console.Write("Enter your total bill amount : ");
            int totalBill = Convert.ToInt32(Console.ReadLine());
            //  =============>    80000

            Console.Write("How many friends : ");
            int friends = Convert.ToInt32(Console.ReadLine());
            // ==============>   4

            int divide = totalBill / friends;
            Console.Write($"Every person has to give : {divide:C0}");
            // ==============>          80000 / 4 ====> 20000









            Console.Write("Enter your total bill amount : ");
            int totalBill = Convert.ToInt32(Console.ReadLine());
            // ===============>    100000

            Console.Write("How many friends : ");
            byte friends = Convert.ToByte(Console.ReadLine());
            // =========>   5

            int  divide = totalBill / friends;
            Console.WriteLine($"Every person has to give : {divide:C0}");
            //  ===============>   100000 / 5 ====> 25000








            Console.Write("Enter your total balance : ");
            int balance = Convert.ToInt32(Console.ReadLine());
            //  =========>  100000

            Console.Write("Enter the amount you wanna withdraw : ");
            int withdraw = Convert.ToInt32(Console.ReadLine());
            //   ============> 70000

            int remain = balance - withdraw;
            Console.WriteLine($"This is your remaining balance : {remain:C0}");










            Console.Write("Enter Your total cost of apartment : ");
            int flat = Convert.ToInt32(Console.ReadLine());
            //      50000

            Console.Write("Please enter the down payment : ");
            int downPay = Convert.ToInt32(Console.ReadLine());
            //      10000

            int sub = flat - downPay;
            //        50000 - 10000====> 40000

            Console.Write("Enter the number of months : ");
            int month = Convert.ToInt32(Console.ReadLine());
            //   5 

            int monthlyPay = sub / month ;
            Console.WriteLine($"This is your monthly average  : {monthlyPay:C0}");
            //               50000- 10000  =====> 40000 / 5 ===>  8000







            Console.Write("Please enter length in feet : ");
            int feet =Convert.ToInt32(Console.ReadLine());
            //    3   

            int inches = feet * 12; 
            Console.WriteLine($"Length in inches : {inches}");
            //     3 * 12 =====> 36 








            Console.Write("Please enter length in feet : ");
            int feet1 = Convert.ToInt32(Console.ReadLine());
            ////    5   

            int inches1 = feet1 * 12;
            Console.WriteLine($"Length in inches : {inches1}");
            //     5 * 12 =====> 60 








            Console.Write("Please enter length in feet : ");
            int feet2 = Convert.ToInt32(Console.ReadLine());
            //    10   

            int inches2 = feet2 * 12;
            Console.WriteLine($"Length in inches : {inches2}");
            //     10 * 12 =====> 120 











            Console.Write("Enter the number of bits : ");
            int bits = Convert.ToInt32(Console.ReadLine());
            //    16 

            int div = 8;

            int bytes = bits / div;
            Console.WriteLine($"Byte(s) : {bytes}");
            //   2 




            Console.Write("Enter the number of bits : ");
            int bits1 =  Convert.ToInt32(Console.ReadLine());   
            //     32


            int bytes1 = bits1 / div;
            Console.WriteLine($"Byte(s) : {bytes1}");
            //  4


            Console.Write("Enter the number of bits : ");
            int bits2 = Convert.ToInt32(Console.ReadLine());
            //  64


            int bytes2 = bits2 / div;
            Console.WriteLine($"Byte(s) : {div}");
            //   8






            Console.Write("Enter the number of Bytes : ");
            int bytes = Convert.ToInt32(Console.ReadLine());
            //   2  

            int mul = 8;

            int bits = bytes * mul;
            Console.WriteLine($"Bits : {bits}");
            //   16  ====================================================







            Console.Write("Enter the number of bytes : ");
            int bytes1 = Convert.ToInt32(Console.ReadLine());
            //4

            int bits1 = bytes1 * mul;
            Console.WriteLine($"Bits : {bits1}");
            //   32  ==========================================








            Console.Write("Enter the number of bytes : ");
            int bytes2 = Convert.ToInt32(Console.ReadLine());
            //  

            int bits2 = bytes2 * mul;
            Console.WriteLine($"Bits : {bits2}");
            //  8  ==================================================









            Console.Write("Enter your  volts : ");
            int volt = Convert.ToInt32(Console.ReadLine());
            //    10 

            float kv = 1000;

            float div = volt / kv;
            Console.WriteLine($"Equal KV : {div}");
            //   10/1000 =====>  0.01===================================






            Console.Write("Enter your volt : ");
            int volt1 = Convert.ToInt32(Console.ReadLine());
            //  250

            float div1 = volt1 / kv;
            Console.WriteLine($"Equal KV : {div1}");
            //  250 / 1000 =====> 0.25*/


            
            Console.Write("Enter the amount in USD : ");
            float usd = Convert.ToInt32(Console.ReadLine());
            //  100 

            float pkr = usd * 285;
            float gbp = pkr / 375;

            Console.WriteLine($"Pkr : {pkr:C0}");
            //   100 * 285 =====>   28500
            Console.WriteLine($"GBP : {gbp:C0}");
            //   28500 / 375 =====>  76   ==========================================

            Console.Write("Enter your amount in usd : ");
            float usd1 = Convert.ToInt32(Console.ReadLine());
            //50

            float pkr1 = usd1 * 285;
            float gbp1 = pkr1 / 375;

            Console.WriteLine($"Pkr : {pkr1:C0}");
            //   285 * 50 =====> 14250
            Console.WriteLine($"GBP : {gbp1:C0}");
            // 14250 / 375 =====>  38
            


            










            









            Console.ReadLine();
        }
    }
}
