using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Divid___Reminder___Modulus
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ahmed";

            //          Divide

            Console.WriteLine(10/2);
            Console.WriteLine(15/4);
            Console.WriteLine(20/3);
            Console.WriteLine(25/5);
            Console.WriteLine(30 / 7);
            Console.WriteLine(18 / 6);
            Console.WriteLine(27/8);
            Console.WriteLine(40 / 9);
            Console.WriteLine(50 / 11);
            Console.WriteLine(33 / 4);
            Console.WriteLine(19 / 5);
            Console.WriteLine(64 / 8);
            Console.WriteLine(77 / 6);
            Console.WriteLine(95 / 10);
            Console.WriteLine(81 / 9);
            Console.WriteLine(56 / 12);
            Console.WriteLine(72 / 7);
            Console.WriteLine(99 / 8);
            Console.WriteLine(120 / 13);
            Console.WriteLine(145 / 12);


            //                  Reminder / Modulus 


            Console.WriteLine("===============================================");


            Console.WriteLine(10 % 2);
            Console.WriteLine(15 % 4);
            Console.WriteLine(20 % 3);
            Console.WriteLine(25 % 5);
            Console.WriteLine(30 % 7);
            Console.WriteLine(18 % 6);
            Console.WriteLine(27 % 8);
            Console.WriteLine(40 % 9);
            Console.WriteLine(50 % 11);
            Console.WriteLine(33 % 4);
            Console.WriteLine(19 % 5);
            Console.WriteLine(64 % 8);
            Console.WriteLine(77 % 6);
            Console.WriteLine(95 % 10);
            Console.WriteLine(81 % 9);
            Console.WriteLine(56 % 12);
            Console.WriteLine(72 % 7);
            Console.WriteLine(99 % 8);
            Console.WriteLine(120 % 13);
            Console.WriteLine(145 % 12);





            Console.ReadLine();
        }
    }
}
