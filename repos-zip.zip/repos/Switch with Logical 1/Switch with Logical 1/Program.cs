﻿



using System.Reflection.Metadata;

Console.Title = "AHMED";



Console.Write("Enter atif : ");
string name = Console.ReadLine();

switch (name == "atif")
{
    case true:
        Console.Write("Enter 1000 : ");
        short fee = Convert.ToInt16(Console.ReadLine());

        switch (fee == 1000)
        {
            case true:
                Console.WriteLine("Valid record.");
                break;
            default:
                Console.WriteLine("Invalid fee.");
                break;
        }

        break;
    default:
        Console.WriteLine("Invalid name.");
        break;

}
Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter dot net : ");
string course = Console.ReadLine();

switch (course == "dot net")
{
    case true:
        Console.Write("Enter >= 5000 :");
        short fee = Convert.ToInt16(Console.ReadLine());
        switch (fee >= 5000)
        {
            case true:
                Console.WriteLine("Valid record.");
                break;
            default:
                Console.WriteLine("Invalid fee.");
                break;
        }
        break;
    default:
        Console.WriteLine("Invalid course.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================



Console.Write("Enter dot net : ");
string course1 = Console.ReadLine();

switch (course1 == "dot net")
{
    case true:
        Console.Write("Enter age >= 15 : ");
        byte age = Convert.ToByte(Console.ReadLine());

        switch (age >= 15)
        {
            case true:
                Console.WriteLine("You can enroll.");
                break;
            default:
                Console.WriteLine("You can not enroll.");
                break;
        }
        break;
    default:
        Console.WriteLine("Wrong course.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter dot net : ");
string course2 = Console.ReadLine();

switch (course2 == "dot net")
{
    case true:
        Console.Write("Enter hyderabad : ");
        string city = Console.ReadLine();

        switch (city == "hyderabad")
        {
            case true:
                Console.WriteLine("Valid record.");
                break;
            default:
                Console.WriteLine("Invalid record.");
                break;
        }

        break;
    default:
        Console.WriteLine("Invalid course.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enter order >= $50 : ");
byte quantity = Convert.ToByte(Console.ReadLine());

switch (quantity >= 50)
{
    case true:
        Console.WriteLine("Do you have a member ship true/false : ");
        bool member = Convert.ToBoolean(Console.ReadLine());
        switch (member == true)
        {
            case true:
                Console.WriteLine("We can give you discount.");
                break;
            default:
                Console.WriteLine("You are not eiligible for discount.");
                break;
        }
        break;
    default:
        Console.WriteLine("Sorry.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

