﻿

Console.Title = "AHMED";

/*Console.Write("Enter one of them s,p,k,b : ");
char ch = Convert.ToChar(Console.ReadLine());

switch (ch)
{
    case 's':
        Console.WriteLine("Sindh.");
        break;
   
}
switch (ch)
{
    case 'p':
        Console.WriteLine("Panjab.");
        break;
   
}
switch (ch)
{
    case 'k':
        Console.WriteLine("Khyber Pakhtunkhwa.");
        break;
   
}
switch (ch)
{
    case 'b':
        Console.WriteLine("Balochistan.");
        break;

}



Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter one of them a,b,c,d : ");
char ch1 = Convert.ToChar(Console.ReadLine());

switch (ch1)
{
    case 'a':
        Console.WriteLine("Arabians.");
        break;
   
}
switch (ch1)
{
    case 'b':
        Console.WriteLine("Bangladesh.");
        break;
   
}
switch (ch1)
{
    case 'c':
        Console.WriteLine("Canada.");
        break;
   
}
switch (ch1)
{
    case 'd':
        Console.WriteLine("Denmark.");
        break;

}



Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter sim code like 300,313,333,345,321 : ");
short nm = Convert.ToInt16(Console.ReadLine());

switch (nm)
{
    case 300:
        Console.WriteLine("Mobilink.");
        break;
}

switch (nm)
{
    case 333:
        Console.WriteLine("Ufone.");
        break;
}

switch (nm)
{
    case 345:
        Console.WriteLine("Telenor.");
        break;
}

switch (nm)
{
    case 321:
        Console.WriteLine("Warid.");
        break;
}

switch (nm)
{
    case 313:
        Console.WriteLine("Zong.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================



Console.Write("Enter any operatore name to see their code like " +
    "Mobilink,Zong,Ufone,Telenor,Warid : ");
string sims = Console.ReadLine();

switch (sims)
{
    case "mobilink":
        Console.WriteLine("0300");
        break;
}


switch (sims)
{
    case "zong":
        Console.WriteLine("0313");
        break;
}


switch (sims)
{
    case "ufone":
        Console.WriteLine("0333");
        break;
}


switch (sims)
{
    case "telenor":
        Console.WriteLine("0345");
        break;
}


switch (sims)
{
    case "Warid":
        Console.WriteLine("0321");
        break;
}
Console.ReadLine();
Console.Clear();

//================================================================
*/

Console.Write("Enter Student name Ali,Asif,Atif : ");
string student = Console.ReadLine();

switch (student)
{
    case "Ali":
        Console.WriteLine("Ali is a C# Student.");
        break;
}


switch (student)
{
    case "Asif":
        Console.WriteLine("Asif is a HTML.");
        break;
}


switch (student)
{
    case "Atif":
        Console.WriteLine("Atif is a Java Student.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter Nokia,Samsung,IPhone : ");
string brands = Console.ReadLine();

switch (brands)
{
    case "Nokia":
        Console.WriteLine("Windows.");
        break;
}


switch (brands)
{
    case "Samsung":
        Console.WriteLine("Android.");
        break;
}


switch (brands)
{
    case "IPhone":
        Console.WriteLine("iOs");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter course DCBM,DIT,CIT : ");
string course = Console.ReadLine();

switch (course)
{
    case "dcbm":
        Console.WriteLine("Faith Offering DCBM.");
        break;
}

switch (course)
{
    case "dit":
        Console.WriteLine("Faith Offering DIT.");
        break;
}

switch (course)
{
    case "cit":
        Console.WriteLine("Faith Offering CIT.");
        break;
}


Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter operator name unary,binary,ternary : ");
string operators = Console.ReadLine();

switch (operators)
{
    case "unary":
        Console.WriteLine("Unary deals with single operands.");
        break;
}

switch (operators)
{
    case "binary":
        Console.WriteLine("Binary deals with two operands.");
        break;
}

switch (operators)
{
    case "ternary":
        Console.WriteLine("Ternary deals with Three operands.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter your name : ");
string  user = Console.ReadLine();

switch (user)
{
    case "admin":
        Console.WriteLine("Welcome Admin.");
        break;
}


switch (user)
{
    case "asif":
        Console.WriteLine("Welcome Sub User.");
        break;
}


switch (user)
{
    case "atif":
        Console.WriteLine("Welcome Data Entry Operator.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter Phone name Nokia,Samsung,IPhone : ");
string phones = Console.ReadLine();

switch (phones)
{
    case "nokia":
        Console.WriteLine("Nokia phones are available.");
        break;
}


switch (phones)
{
    case "samsung":
        Console.WriteLine("Samsung phones will be available from 1st June.");
        break;
}


switch (phones)
{
    case "iphone":
        Console.WriteLine("IPhone is not available.");
        break;
}
Console.ReadLine();
Console.Clear();

//================================================================



