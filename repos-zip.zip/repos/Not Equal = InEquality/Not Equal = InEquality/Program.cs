using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Not_Equal___InEquality
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string str1 = "html";
            string str2 = "CSharp";
            string str3 = "DOT NET";
                        //              Not Equal / InEquality 

            Console.WriteLine(str1!="html");            // false
            Console.WriteLine(str2!=str1);              // true
            Console.WriteLine(str2!=str3);              // true
            Console.WriteLine(str1!="HTML");            // true
            Console.WriteLine(str2 != "C#");            // true
            Console.WriteLine(str3!="DOT NET");         // false
            Console.WriteLine(str3 !=".NET");           // true
            Console.WriteLine(str3!="C#.NET");          // true
            Console.WriteLine(str1!=str3);              // true
            Console.WriteLine(str1!="C#");              // true
            Console.WriteLine("DOT NET "!= "C#");       // true
            Console.WriteLine(str3!= " dot net");       // true
            Console.WriteLine(str2 != "c#");            // true
            Console.WriteLine(str2!=str3);              // true  

            Console.ReadLine();
        }
    }
}
