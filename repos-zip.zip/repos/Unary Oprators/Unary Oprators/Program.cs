using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unary_Oprators
{
    internal class Program
    {
        static void Main(string[] args)
        {
                                                 //All about PRE decrement

            byte a = 49;
            Console.WriteLine(--a);     //48
            Console.WriteLine(a);       //48

            byte b = 75;
            Console.WriteLine(--b);     //74
            Console.WriteLine(b);       //74

            byte c = 99;
            Console.WriteLine(--c);     //98
            Console.WriteLine(c);       //98

            byte d = 49;
            byte e = --d;
            Console.WriteLine($"{d}:{e}");  //d = 48 / e = 48

            byte f = 75;
            byte g = --f;
            Console.WriteLine($"{f}:{g}"); //f = 74 / g = 74

            byte h = 99;
            byte i = --h;
            Console.WriteLine($"{h}:{i}"); //h = 98 / i = 98

            byte j = 39;
            Console.WriteLine(--j);     //j = 38 
            Console.WriteLine(j);       //j = 38

            byte k = 85;
            Console.WriteLine(--k);     //k = 84
            Console.WriteLine(k);       //k = 843

            byte l = 109;
            Console.WriteLine(--l);     //l = 108
            Console.WriteLine(l);       //l = 108

            byte m = 59;
            byte n = --m;
            Console.WriteLine($"{m}:{n}");      //m = 58 / n = 58

            byte o = 45;
            byte p = --o;
            Console.WriteLine($"{o}:{p}");      //o = 44 / p = 44

            ushort q = 999;
            ushort r = --q;
            Console.WriteLine($"{q}:{r}");      //q = 998 / r = 998







            Console.ReadLine();
        }
    }
}
