﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IF_with_Logical_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
