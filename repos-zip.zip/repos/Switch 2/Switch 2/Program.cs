﻿
Console.Title = "AHMED";


Console.Write("Enter user : ");
string user = Console.ReadLine();

switch (user)
{
    case "user":
        Console.WriteLine("Hello user ");
}