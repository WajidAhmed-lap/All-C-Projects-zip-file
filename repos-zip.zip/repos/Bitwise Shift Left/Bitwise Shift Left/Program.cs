using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bitwise_Shift_Left
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ahmed";



            Console.WriteLine(10 << 1);
            Console.WriteLine(10 << 2);
            Console.WriteLine(10 << 3);
            Console.WriteLine(10 << 4);
            Console.WriteLine(10 << 5);
            Console.WriteLine(15 << 1);
            Console.WriteLine(15 << 2);
            Console.WriteLine(15 << 3);
            Console.WriteLine(20 << 1);
            Console.WriteLine(20 << 2);
            Console.WriteLine(150 << 2);
            Console.WriteLine(150 << 1);
            Console.WriteLine(140 << 2);
            Console.WriteLine(35 << 2);
            Console.WriteLine(35 << 1);
            Console.WriteLine(200 << 1);






            Console.ReadLine();
        }
    }
}
