﻿
Console.Title = "AHMED";

Console.Write("Enter temperature <5 : ");
sbyte temp = Convert.ToSByte(Console.ReadLine());

switch (temp <= 5 )
{
    case true:
        Console.WriteLine("Warning it's to cold outside.");
        break;

        
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enter your quantity <10 : ");
byte quant =  Convert.ToByte(Console.ReadLine());

switch (quant < 10)
{
    case true:
        Console.WriteLine("Not eligible for discount.");
        break;
}


Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter your speed <60 : ");
byte speed = Convert.ToByte(Console.ReadLine());

switch  (speed < 60 )
{
    case true:
        Console.WriteLine("You are within the speed.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter your battery percentage : ");
byte per = Convert.ToByte(Console.ReadLine());

switch (per <= 20 )
{
    case true:
        Console.WriteLine("Low Battery : Please charge.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter your marks <40 : ");
byte marks = Convert.ToByte(Console.ReadLine());    

switch (marks < 40 )
{
    case true:
        Console.WriteLine("Student fail in exam.");
        break;
    default:
        Console.WriteLine("Student pass in exam.");
        break; 
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter your marks <60 : ");
byte marks1 = Convert.ToByte(Console.ReadLine());

switch (marks1 < 60)
{
    case true:
        Console.WriteLine("Grade C.");
        break; 
}
Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter your annual income <500000: ");
int income = Convert.ToInt32(Console.ReadLine());

switch (income < 50000)
{
    case true:
        Console.WriteLine("Not eligible for income tax.");
        break;
}

