﻿

Console.Title = "Ahmed";


/*Console.WriteLine("\t\t\t   Q No : 1");

Console.Write("Enter Python : ");
string course = Console.ReadLine();

if (course == "Python")
{
    Console.WriteLine("Correct course.");
}

else if (course !="Python")
{ Console.WriteLine("This is not Python course."); }

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("\t\t\t          Q No : 2 ");

Console.WriteLine("Enter your age 18 : ");
byte age = Convert.ToByte(Console.ReadLine());

if (age == 18)
{
    Console.WriteLine("OKay.");
}
else if (age != 18)
{
    Console.WriteLine("You are not exactly 18 years old.");
}

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("\t\t\t               Q No  : 3 ");

Console.WriteLine("Enter your password admin123 : ");
string pass = Console.ReadLine();

if (pass == "admin123")
{
    Console.WriteLine("Correct password.");
}

else if (pass != "admin123")
{
    Console.WriteLine("Password invalid.");
}


Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("\t\t\t           Q No : 4");

Console.WriteLine("Enter number 0 : ");
byte zero = Convert.ToByte(Console.ReadLine());

if (zero != 0)
{
    Console.WriteLine("Number is non zero.");
}


Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("\t\t\t                Q no : 5 ");

Console.WriteLine("Enter number 9 : ");
byte num1 = Convert.ToByte(Console.ReadLine());

Console.WriteLine("Enter number 9 : ");
byte num2 = Convert.ToByte(Console.ReadLine());

if (num1 != num2)
{
    Console.WriteLine("Both numbers are diffirent.");
}
Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("\t\t\t             Q No : 6 ");

Console.WriteLine("Enter a : ");
char ch = Convert.ToChar(Console.ReadLine());

if (ch != 'a')
{
    Console.WriteLine("Character is not a.");
}

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("\t\t\t                     Q No : 7 ");

Console.WriteLine("Enter your mark 50 : ");
byte marks = Convert.ToByte(Console.ReadLine());

if (marks != 50)
{
    Console.WriteLine("Marks is not equal to passing marks.");
}

Console.ReadLine();
Console.Clear();

//================================================================

 

Console.WriteLine("\t\t\t                     Q No : 8 ");

Console.WriteLine("Enter  100 : ");
byte number = Convert.ToByte(Console.ReadLine());

if (number != 100)
{
    Console.WriteLine("Not a century.");
}

Console.ReadLine();
Console.Clear();
*/
//================================================================


Console.WriteLine("\t\t\t               Q No  : 9 ");

Console.WriteLine("Enter your username : ");
string userName = Console.ReadLine();

Console.WriteLine("Enter your password  123 : ");
string password = Console.ReadLine();

if (userName != "admin" || password != "123")
{
    Console.WriteLine("Login failed.");
}

Console.ReadLine();
Console.Clear();

//================================================================

/*
Console.WriteLine("\t\t\t               Q No  : 10 ");

Console.WriteLine("Enter city name karachi : ");
string city = Console.ReadLine();

if (city != "karachi")
{
    Console.WriteLine("You are not in karachi.");
}


Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("\t\t\t               Q No  : 11 ");

Console.WriteLine("Enter color name red : ");
string colour = Console.ReadLine();

if (colour != "red")
{
    Console.WriteLine("This is not red color.");
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("\t\t\t               Q No  : 12 ");

Console.WriteLine("Enter your grade A : ");
char grade = Convert.ToChar(Console.ReadLine());

if (grade != 'A')
{
    Console.WriteLine("You did not get A grade.");
}
Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("\t\t\t               Q No  : 13 ");

Console.WriteLine("Enter number neither 0 or 1 : ");
byte number1 = Convert.ToByte(Console.ReadLine());

if (number1!= 0 &&  number1 != 1)
{
    Console.WriteLine("Number is neither 0 nor 1.");
}

Console.ReadLine();
Console.Clear();

//===========================================================

Console.WriteLine("\t\t\t               Q No  : 14 ");

Console.WriteLine("Enter your marks 100 : ");
byte marks2 = Convert.ToByte(Console.ReadLine());

if (marks2 != 100)
{
    Console.WriteLine("Perfect marks not achieved.");
}

Console.ReadLine();
Console.Clear();

//===========================================================

Console.WriteLine("\t\t\t               Q No  : 15 ");

Console.WriteLine("Enter day name sunday : ");
string day = Console.ReadLine();

if (day.ToLower() != "sunday")
{
    Console.WriteLine("Today is not holiday.");
}
Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("\t\t\t               Q No  : 16 ");

Console.WriteLine("Enter number 100 or 200 : ");
byte number3 = Convert.ToByte(Console.ReadLine());

if (number3 != 100 && number3 != 200)
{
    Console.WriteLine("Not allowed.");
}
Console.ReadLine();
Console.Clear();

//======================================================================

Console.WriteLine("\t\t\t               Q No  : 18 ");

Console.WriteLine("Enter day saturday or sunday : ");
string days = Console.ReadLine();

if (days.ToLower() != "sunday" && days.ToLower() != "saturday")
{
    Console.WriteLine("Not weekend.");
}
Console.ReadLine();
Console.Clear();
//=======================================================================

Console.WriteLine("\t\t\t               Q No  : 19 ");

Console.WriteLine("Enter number 5,10 or 15 : ");
byte numbers = Convert.ToByte(Console.ReadLine());

if (numbers != 5 && numbers != 10 && numbers != 15)
{
    Console.WriteLine("Number is not in Special range.");
}
Console.ReadLine();
Console.Clear();

//==========================================================
*/



