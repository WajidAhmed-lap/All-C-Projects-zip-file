using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IF_with_Relational_1
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.Title = "Ahmed";


            Console.Write("Enter your age to checking your vote.");
            byte age = Convert.ToByte(Console.ReadLine());

            if (age >= 18)
            { Console.WriteLine("You can vote."); }

            else { Console.WriteLine("Sorry"); }

            Console.ReadLine();
            Console.Clear();
            // ==========================================================

            Console.Write("I wanna check temprature.");
            byte temp = Convert.ToByte(Console.ReadLine());

            if (temp >= 30)
            { Console.WriteLine("It's hot outside."); }
            if (temp <= 10)
            { Console.WriteLine("It's cold outside."); }
            else if (temp <= 29)
            { Console.WriteLine("It's normal."); }
            Console.ReadLine();
            Console.Clear();
            //==========================================================

            Console.Write("Enter the first number.");
            byte nm1 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter the second number.");
            byte nm2 = Convert.ToByte(Console.ReadLine());

            if (nm1 > nm2)
            { Console.WriteLine("First number is greater than second."); }
            else if (nm1 < nm2)
            { Console.WriteLine("First number is less than second."); }
            Console.ReadLine();
            Console.Clear();

            //================================================================


            Console.Write("Enter your marks  to check your result.");
            byte result = Convert.ToByte(Console.ReadLine());


            if (result >= 50)
            { Console.WriteLine("You are pass."); }
            else { Console.WriteLine("You are fail."); }
            Console.ReadLine();
            Console.Clear();



//            ============================================

            Console.Write("Enter the water temprature.");
            sbyte temp1 = Convert.ToSByte(Console.ReadLine());

            if (temp1 <= 0)
            { Console.WriteLine("Water is in solid state (ice)."); }
            else { Console.WriteLine("Water is in liquid state."); }
            Console.ReadLine();
            Console.Clear();


            //          =================================================================

            Console.Write("Enter any number to check is it positive or negative.");
            sbyte check = Convert.ToSByte(Console.ReadLine());

            if (check >= 0)
            { Console.WriteLine("The number is positive."); }
            else { Console.WriteLine("The number is zero or negative."); }
            Console.ReadLine();
            Console.Clear();

            //        =================================================================

            Console.Write("Enter your age.");
            byte age1 = Convert.ToByte(Console.ReadLine());

            if (age1 >= 65)
            { Console.WriteLine("Eligible for retirement."); }
            else { Console.WriteLine("Not eligible for retirement."); }

            Console.ReadLine();
            Console.Clear();



//            =============================================================








            Console.ReadLine();
        }
    }
}
