using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical_Operator_OR
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "...";


            byte e = 5;
            byte b =11;
            byte c = 9;
            byte d = 15;
            char ch = 'e';
            string str = "JS";


            Console.WriteLine(d == 15 || c == 9 );
            //                  1      +    1  ======>  2
            //                  True    ||   True   ======> True
            Console.WriteLine(ch != 'E' || str == "JS");
            //                  1       +     1 ======> 2
            //                  True    ||    True =====> True 
            Console.WriteLine(d >= 9 || c >= 9 );
            //                  1     +   1 =====>  2
            //                  True  ||   True  ====> True
            Console.WriteLine(e == 11 || d == 15 );
            //                  0      +  1 ======>     1
            //                  True   ||  True  =====> True

            




            Console.ReadLine();
        }
    }
}
