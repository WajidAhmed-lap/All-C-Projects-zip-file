﻿

Console.Title = "AHMED";

Console.Write("Enter your order cost 50 : ");
byte cost = Convert.ToByte(Console.ReadLine());

Console.WriteLine("Are you a premium member yes/no : ");
string check = Console.ReadLine();

switch (cost == 50 || check == "Yes")
{
    case true:
        Console.WriteLine("You are eligible for free shipping.");
        break;
    default:
        Console.WriteLine("You are not eligible for free shipping.");
        break;

}
Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enter any vowel letter a,e,i,o,u : ");
char ch = Convert.ToChar(Console.ReadLine());

switch (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u'  )
{
    case true:
        Console.WriteLine($"The character {ch} is vowel.");
        break;
        default:
        Console.WriteLine($"The character {ch} is not vowel.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter your marks 70 : ");
byte marks = Convert.ToByte(Console.ReadLine());

Console.Write("Do you have a recommendation yes/no  : ");
string recommend= Console.ReadLine();

switch (marks == 70 || recommend == "yes")
    {
    case true:
        Console.WriteLine("You have passed the course.");
        break; default:
        Console.WriteLine("You are fail.");
        break;

    }

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter your GPA 5.0 : ");
float gpa = Convert.ToSingle(Console.ReadLine());

Console.Write("Are you involved in community true/false : ");
bool yes = Convert.ToBoolean(Console.ReadLine());

switch (gpa == 5.0 || yes == true )
    {
    case true:
        Console.WriteLine("You are eligible for scholarship.");
        break; default:
        Console.WriteLine("You are not eligible for scholarship.");
        break;

    }

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("How old are you 80 : ");
byte age =  Convert.ToByte(Console.ReadLine());

Console.Write("Do you have a valid student id true/false : ");
bool student =  Convert.ToBoolean(Console.ReadLine());

switch (age == 80 || student == true)
{
    case true:
        Console.WriteLine("You are eligible for discount.");
        break; default:
        Console.WriteLine("You are not eligible for discount.");
        break;
            
}

Console.ReadLine();
Console.Clear();

//================================================================


