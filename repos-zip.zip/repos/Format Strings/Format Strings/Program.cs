﻿Console.Title = "Ahmed";


Console.WriteLine("Enter your salary to see them in currency format : ");
int salary = Convert.ToInt32(Console.ReadLine());

Console.Clear();
Console.WriteLine($"Here is your salary : {salary:C}");

Console.ReadLine();
Console.Clear();

//===================================================================================

Console.WriteLine("Enter your salary to see them in currency format : ");
int salary1 = Convert.ToInt32(Console.ReadLine());

Console.Clear();
Console.WriteLine($"Here is your salary : {salary1:C1}");

Console.ReadLine();
Console.Clear();

//===================================================================================

Console.WriteLine("Enter your salary to see them in currency format : ");
int salary2 = Convert.ToInt32(Console.ReadLine());

Console.Clear();
Console.WriteLine($"Here is your salary : {salary2:C0}");

Console.ReadLine();
Console.Clear();

//===================================================================================

Console.WriteLine("Enter your product price i'll separator it : ");
int price = Convert.ToInt32(Console.ReadLine());

Console.Clear();

Console.WriteLine($"Product price : {price:N2}");

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter your product price i'll separator it : ");
int price1 = Convert.ToInt32(Console.ReadLine());

Console.Clear();

Console.WriteLine($"Product price : {price1:N1}");

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter your product price i'll separator it : ");
int price2 = Convert.ToInt32(Console.ReadLine());

Console.Clear();

Console.WriteLine($"Product price : {price2:N0}");

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enrer any decimal number : ");
float number = Convert.ToSingle(Console.ReadLine());

Console.Clear();

Console.WriteLine($"Your number with 2 decimal : {number:F2}");

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enrer any decimal number : ");
float number1 = Convert.ToSingle(Console.ReadLine());

Console.Clear();

Console.WriteLine($"Your number with 2 decimal : {number1:F2}");

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter your number and see it in hexadecimal : ");
int hexa = Convert.ToInt32(Console.ReadLine());

Console.Clear();

Console.WriteLine($"This is your hexadecimal value : {hexa:X}");

Console.ReadLine();
Console.Clear();

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter your number and see it in hexadecimal : ");
int hexa1 = Convert.ToInt32(Console.ReadLine());

Console.Clear();

Console.WriteLine($"This is your hexadecimal value : {hexa1:X}");

Console.ReadLine();
Console.Clear();

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter your number and see it in hexadecimal : ");
int hexa2= Convert.ToInt32(Console.ReadLine());

Console.Clear();

Console.WriteLine($"This is your hexadecimal value : {hexa2:X}");

Console.ReadLine();
Console.Clear();

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter your number i'll convert it in all" +
    "string format : ");
ushort all = Convert.ToUInt16(Console.ReadLine());

Console.Clear();

Console.WriteLine("Your number in currency format : {0:c}",all);
Console.WriteLine("\nYour number in number format : {0:n}",all);
Console.WriteLine("\nYour number in hexadecimal format : {0:x}",all);
Console.WriteLine("\nYour number in fixed format : {0:f}",all);

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enter your number i'll convert it in all" +
    " string format : ");
short all1 = Convert.ToInt16(Console.ReadLine());

Console.Clear();

Console.WriteLine("Your number in currency format : {0:c}",all1);
Console.WriteLine("\nYour number in number format : {0:n}",all1);
Console.WriteLine("\nYour number in hexadecimal format : {0:X}",all1);
Console.WriteLine("\nYour number in fixed format : {0:f}",all1);

Console.ReadLine();
Console.Clear();

//================================================================