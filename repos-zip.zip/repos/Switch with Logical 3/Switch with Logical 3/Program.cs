﻿

Console.Title = "AHMED";

Console.Write("Enter your age 20 : ");
byte age = Convert.ToByte(Console.ReadLine());

Console.WriteLine("Do you have license yes/no : ");
string license = Console.ReadLine();

switch (age == 20 && license == "yes")

{
    case true:
        Console.WriteLine("You can drive.");
        break;
    default:
        Console.WriteLine("You can not drive.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter your grade A/B : ");
char grade = Convert.ToChar(Console.ReadLine());

Console.Write("Enter your marks 70 : ");
byte marks = Convert.ToByte(Console.ReadLine());

switch (grade == 'A' || grade == 'B' && marks == 70)
{
    case true:
        Console.WriteLine("Congrats! You meet the admission criteria.");
        break;
    default:
        Console.WriteLine("Sorry! You don't meet the admission criteria.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter temperature 90 : ");
byte temp = Convert.ToByte(Console.ReadLine());

switch (temp == 90)
{
    case true:
        Console.WriteLine("Temperature within the range.");
         break;
        default:
        Console.WriteLine("Temperature out of range.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter your age 70 : ");
byte age1 = Convert.ToByte(Console.ReadLine());

switch(age1 == 70)
{
    case true:
        Console.WriteLine("You are not in working age range.");
        break;
        default:
        Console.WriteLine("In working age range.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter your grade A,B,C : ");
char ch1 = Convert.ToChar(Console.ReadLine());

switch (ch1 == 'A' || ch1 == 'B' || ch1 == 'C')
{
    case true:
        Console.WriteLine("Excellent grade.");
        break;
    default:
        Console.WriteLine("Grade is not excellent.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter fruit name Apple,Banana : ");
string fruit = Console.ReadLine();

switch (fruit == "Apple" || fruit == "Banana")
{
    case true:
        Console.WriteLine("Fruit detected.");
        break;
        default:
        Console.WriteLine("No fruit detected.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Say Hello,Hi,Hey : ");
string greet = Console.ReadLine();

switch (greet == "Hello" || greet == "Hi" || greet == "Hey")
{
    case true:
        Console.WriteLine("Greetings detected.");
        break; default:
        Console.WriteLine("No greetings detected.");
        break;

}


Console.ReadLine();
Console.Clear();

//================================================================




