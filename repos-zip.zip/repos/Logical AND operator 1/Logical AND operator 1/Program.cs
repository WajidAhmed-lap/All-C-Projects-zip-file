using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical_AND_operator_1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "...";




            byte a = 5;
            byte b = 10;
            byte c = 15;
            byte d = 20;
            char ch = 'c';
            string str = "html";

            Console.WriteLine(a == 5 && b == 10 );
            //                  1    *   1   ======> 1 
            //                  True && True ======>   True
            Console.WriteLine(ch == 'c' && str == "html");
            //                   1      *     1   ====> 1
            //                  True    && True   ====> True
            Console.WriteLine(a == 15 && d == 25 );
            //                  0       *   0     ====>   0
            //                  False   &&    False ====> False
            Console.WriteLine(str == "HTML" && ch == c);
            //                  0           *    1  ======>  0
            //                  False       &&    True  ====> False
            Console.WriteLine(a >= 1 && c <= 15);
            //                  1    *   1  =========>  1
            //                  True &&  True   ==========>  True
            Console.WriteLine(ch != 'A' && str !="C#");
            //                  1       *     1 ======> 1
            //                   True   &&      True =====> True

            






            Console.ReadLine();
        }
    }
}
