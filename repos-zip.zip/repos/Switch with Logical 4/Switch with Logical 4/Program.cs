﻿

Console.Title = "AHMED";


Console.Write("Enter your age 20 : ");
byte age = Convert.ToByte(Console.ReadLine());

Console.WriteLine("Are you local yes/no : ");
string local = Console.ReadLine();

switch (age == 20 && local == "Yes")
{
    case true:
        Console.WriteLine("You can vote.");
        break;
    default:
        Console.WriteLine("You can not vote.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter your written marks 70 : ");
byte marks  = Convert.ToByte(Console.ReadLine());

Console.WriteLine("Enter your practical marks 50 : ");
byte practical = Convert.ToByte(Console.ReadLine());

switch (marks == 70 && practical == 50)
{
    case true:
        Console.WriteLine("Pass.");
        break; default:
        Console.WriteLine("Fail.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter number 90 :");
byte num  = Convert.ToByte(Console.ReadLine());

switch (num == 90)
{
    case true:
        Console.WriteLine("Number is within the range.");
        break; 
    default:
        Console.WriteLine("Number is out of range.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter your math marks 80 : ");
byte mark = Convert.ToByte(Console.ReadLine());

Console.Write("Enter your science marks 70 : ");
byte sci  = Convert.ToByte(Console.ReadLine());

switch (mark == 80 && sci == 70 )
{
    case true:
        Console.WriteLine("Student Excel in math and science.");
        break;
        default:
        Console.WriteLine("Student does not excel in both subjects.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter teperature 70 : ");
byte temp = Convert.ToByte(Console.ReadLine());

switch (temp == 70)
{
    case true:
        Console.WriteLine("Water is in liquid state.");
        break;
    default:
        Console.WriteLine("Water is not in liquid state.");
        break;


}
Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter your age 25 : ");
byte age1 = Convert.ToByte(Console.ReadLine());

Console.Write("Are you employe yes/no : ");
string check = Console.ReadLine();

switch (age1 == 25 && check == "Yes")
{
    case true:
        Console.WriteLine("Person is in the prime working age and employed.");
        break;
        default:
        Console.WriteLine("Person is not in the prime working age and / or not employed");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


