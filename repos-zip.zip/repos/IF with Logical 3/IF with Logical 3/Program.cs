﻿Console.Title = "AHMED";



Console.Write("Please enter your age : ");
byte age = Convert.ToByte(Console.ReadLine());

Console.Write("Do you have a valid Driving license : ");
string yes_no  = Console.ReadLine();


if (age >= 18 && yes_no == "yes")
{
    Console.WriteLine("You are eligible to drive.");
}

else
{
    Console.WriteLine("You are not eligible to drive.");
}
    Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter your grade : ");
char grade = Convert.ToChar(Console.ReadLine());

Console.Write("Enter your percentage : ");
float percentage  = Convert.ToSingle(Console.ReadLine());

if (grade == 'A' || grade == 'B' && percentage >= 65 )
{
    Console.WriteLine("Congrats! You meet the admission criteria.");
}

else
{
    Console.WriteLine("Sorry!You don't meet the admission criteria.");
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter temperature : ");
byte temp = Convert.ToByte(Console.ReadLine());

if (temp>= 0  && temp <= 100)
{
    Console.WriteLine("Temperature within range.");

}

else { Console.WriteLine("Temperature out of range."); }

Console.ReadLine();
Console.Clear();

//================================================================


Console.Write("Enter your age : ");
byte age1 =  Convert.ToByte(Console.ReadLine());

if (age1 <= 16 || age1 >= 65)
{
    Console.WriteLine("Not in working age range.");
}

else { Console.Write("In working age range."); }
Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter your grade : ");
char grade1 = Convert.ToChar(Console.ReadLine());

if ( grade1 == 'A' || grade1 == 'B' || grade1 == 'C'  )
{
    Console.WriteLine("Excellent grade.");

}

else { Console.WriteLine("Grade is not excellent."); }

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter any fruit name : ");
string fruit = Console.ReadLine();

if ( fruit == "apple" || fruit == "banana" || fruit == "mango" )
    {
    Console.WriteLine("Fruit detected.");
    }

else { Console.WriteLine("No fruit detected."); }

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter your age : ");
byte age2 = Convert.ToByte(Console.ReadLine());

Console.Write("Do you have a valid id card : ");
string id =  Console.ReadLine();

if (age2 < 18 || age2 > 65 || id == "yes")
{
    Console.WriteLine("Eligible for discount.");
}

else
{
    Console.WriteLine("Not eligible for discount.");
}

Console.ReadLine();
Console.Clear();

//================================================================
Console.Write("Enter your comment : ");
string comment =  Console.ReadLine();

if (comment == "hi" || comment == "hello" || comment == "hey")
{
    Console.WriteLine("Greetings detected.");
}

else
{
    Console.WriteLine("No greeting detected.");
}

Console.ReadLine();
Console.Clear();

//================================================================