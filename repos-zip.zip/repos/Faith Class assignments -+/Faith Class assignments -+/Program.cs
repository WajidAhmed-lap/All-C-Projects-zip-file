using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace Faith_Class_assignments___
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ahmed";

            /*Console.Write("Enter the number of apple boxex in the store : ");
            byte box = Convert.ToByte(Console.ReadLine());
            //          10

            Console.Write("Enter the number of apples in each box : ");
            byte apples = Convert.ToByte(Console.ReadLine());
            //    12   

            byte total = Convert.ToByte(box * apples);
            Console.WriteLine($"Total number of apples in the store : {total}");
            //   10  *  =====>   120 










            Console.Write("Enter the amount of money in yout wallet : ");
            ushort money = Convert.ToUInt16(Console.ReadLine());
            //          10000

            Console.Write("Enter the amount of money spent on groceries : ");
            ushort spent = Convert.ToUInt16(Console.ReadLine());
            //          8000

            ushort remain = Convert.ToUInt16(money - spent);
            //          10000 - 8000 ===============>   2000
            Console.WriteLine("Money left in wallet : {0}", remain);








            Console.Write("Enter the number of pizzas you wanna buy : ");
            byte pizza = Convert.ToByte(Console.ReadLine());
            //   5

            ushort fixPrice = 800;

            ushort total = Convert.ToUInt16(pizza * fixPrice);
            //          5 * 800 ==========>  4000
            Console.Write("Total cost of pizzas : {0:C0}",total);









            Console.Write("I have : ");
            ushort money = Convert.ToUInt16(Console.ReadLine());
            // 10000

            Console.Write("Groceries amount : ");
            ushort grocery = Convert.ToUInt16(Console.ReadLine());
            //   7000

            Console.Write("Transprotation amount : ");
            ushort transport = Convert.ToUInt16(Console.ReadLine());
            //    500

            Console.Write("Lunch amount : ");
            ushort lunch = Convert.ToUInt16(Console.ReadLine());
            //   1000

            ushort remain =Convert.ToUInt16(money-grocery-transport-lunch);
            //      7000-500-1000- ==========>  1500
            Console.WriteLine($"Money left : {remain:C0}");








            Console.Write("Enter the total bill amount : ");
            ushort bill = Convert.ToUInt16(Console.ReadLine());
            //    10000

            Console.Write("Enter the number of friends : ");
            byte friends = Convert.ToByte(Console.ReadLine());
            //      4   

            ushort hasToPay = Convert.ToUInt16(bill / friends);
            //      10000 / 4 ============>  2500
            Console.WriteLine("Each person has to pay : {0:C0}",hasToPay);*/










            Console.Write("Enter the gallon price : ");
            ushort gallon = Convert.ToUInt16(Console.ReadLine());
            //      500

            Console.Write("Total gallon required  : ");
            byte need = Convert.ToByte(Console.ReadLine());
            // 5

            Console.Write("Labor cost : ");
            ushort labor = Convert.ToUInt16(Console.ReadLine());
            //      3000

            ushort total = Convert.ToUInt16(gallon * need + labor);
            //    500 * 5 + 3000 =======>   5500
            Console.WriteLine($"Total  room painting cost : {total:C0}");













            Console.ReadLine();
        }
    }
}