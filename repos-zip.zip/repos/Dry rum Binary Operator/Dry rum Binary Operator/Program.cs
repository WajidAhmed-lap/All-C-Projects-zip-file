using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dry_rum_Binary_Operator
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ahmed";
            /*//Dry run   aboout substraction
             


            Console.Write("Enter your birthyear : ");
            short birthyear = Convert.ToInt16(Console.ReadLine());
            //       2010



            int age  = 2026 - birthyear;
                  //    2026 - 2010
                  //    16

            Console.WriteLine(age);
            //          16



            Console.Write("Enter your Monthly Income : ");
            int income = Convert.ToInt32(Console.ReadLine());
                //    1000000

            Console.Write("How much you have invested : ");
            int invest = Convert.ToInt32(Console.ReadLine());
            //    300000

            int remainig = income - invest;
                //        1000000 - 300000
                //             700000

            Console.Write($"Your remaining balance is : {remainig:C0}");
               //             700000
             

            Console.Write("Please enter your loan amount : ");
            int loanamount = Convert.ToInt32(Console.ReadLine());
            //      2500000

            Console.Write("Input how much you have returned : ");
            int returnedamount = Convert.ToInt32(Console.ReadLine());
            //      400000

            int remain = loanamount - returnedamount;
            //    2500000 - 400000
            //       2100000

            Console.Write($"Here is your remaining amount : {remain}");
            //       2100000

            // about Addition

            Console.Write("Enter your Basic salary : ");
            int salary = Convert.ToInt32(Console.ReadLine());
            //    125000

            Console.Write("Your Bonus : ");
            int bonus = Convert.ToInt32(Console.ReadLine());
            // 25000

            int total = salary + bonus;
            //          125000 + 25000
            //              150000

            Console.Write($"This is your total salary : {total}");
            //              150000


            Console.Write("Enter your mobile price : ");
            int price = Convert.ToInt32(Console.ReadLine());
            //      90000

            Console.Write("Charger price : ");
            int charger = Convert.ToInt32(Console.ReadLine());
            //      3000

            int total = price + charger;
            //          90000 + 3000
            //          93000

            Console.Write($"Your total bill : {total}");
            //                                  93000


            Console.Write("Enter your food expense : ");
            int food = Convert.ToInt32(Console.ReadLine());
            //      80000

            Console.Write("your travel expense : ");
            int travel = Convert.ToInt32(Console.ReadLine());
            //    25000

            int add = food + travel;
            //        80000 + 25000

            Console.Write($"Here is your Total expenses : {add}");
            //                                            105000


            Console.Write("Enter your Product price : ");
            int product = Convert.ToInt32(Console.ReadLine());
            //      50000

            Console.Write("Quantity : ");
            byte quantity = Convert.ToByte(Console.ReadLine());
            //          5 

            int  total = product * quantity;
            //           50000   * 5
            //              250000

            Console.Write($" This is your total amount : {total:C0}");
            //                                            250000


            Console.Write("Enter Salary : ");
            int salary = Convert.ToInt32(Console.ReadLine());
            //  100000

            Console.Write("Month : ");
            byte month = Convert.ToByte(Console.ReadLine());
            // 12 

            int multiply = salary * month;
            //              100000 * 12 

            Console.Write($"This is your yearly salary : {multiply:C0}");

            Console.Write(" Enter daily wage : ");
            short daily = Convert.ToInt16(Console.ReadLine());
            // 5000

            Console.Write(" Working day : ");
            byte workingDays = Convert.ToByte(Console.ReadLine());
            // 30 

            int mul = daily * workingDays;
            //          5000 * 30 

            Console.Write($" Your total salary : {mul:C0}");
            //                                   150000


            Console.Write("Enter total amount : ");
            int amount = Convert.ToInt32(Console.ReadLine());
            //100000

            Console.Write("People : ");
            byte people = Convert.ToByte(Console.ReadLine());
            // 5 

            int divide = amount / people;
            // 20000

            Console.Write($"Per person has to return : {divide:C0}");
            //                                          20000

            Console.Write("Enter total salary : ");
            int salary = Convert.ToInt32(Console.ReadLine());
            //  2500000

            Console.Write("Months : ");
            byte months = Convert.ToByte(Console.ReadLine());
            // 12 

            int divide = salary / months;
            // 208333.3333333333

            Console.Write($"Per month : {divide:C2}");
            //                          208333.3333333333


            Console.Write("Enter total budget : ");
            ushort budget = Convert.ToUInt16(Console.ReadLine());
            // 50000

            Console.Write("Months : ");
            byte months = Convert.ToByte(Console.ReadLine());
            //  10

             int div = budget / months;
            // 5000

            Console.Write($"Average : {div:C0}");*/






            


            Console.ReadLine();
        }
    }
}
