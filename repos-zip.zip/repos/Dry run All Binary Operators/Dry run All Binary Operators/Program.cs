using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dry_run_All_Binary_Operators
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ahmed";
            //                  Dry run  


            Console.Write("Please enter your total marks : ");
            short totalMarks = Convert.ToInt16(Console.ReadLine());
            //     500       

            Console.Write("Enter your obtain marks : ");
            short obtainMarks = Convert.ToInt16(Console.ReadLine());
            //    400

            int lostMarks = totalMarks - obtainMarks; 
            //              500        -    400
            //                      100

            Console.WriteLine($"you did your best but you lost remaining marks : {lostMarks}");
            //                                              100





            Console.ReadLine();
        }
    }
}
