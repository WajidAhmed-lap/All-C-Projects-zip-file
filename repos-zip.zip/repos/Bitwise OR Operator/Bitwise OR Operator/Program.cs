using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bitwise_OR_Operator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ahmad";


            Console.WriteLine("OR Operator");
            Console.WriteLine(3|7);
            Console.WriteLine(10|5);
            Console.WriteLine(12|4);
            Console.WriteLine(19|3);
            Console.WriteLine(19|4);
            Console.WriteLine(11|4);
            Console.WriteLine(21|5);
            Console.WriteLine(15|3);
            Console.WriteLine(17|7);
            Console.WriteLine(24|6);
            Console.WriteLine(32|16);
            Console.WriteLine(39|13);
            Console.WriteLine(40|14);
            Console.WriteLine(56 | 2);
            Console.WriteLine(39 | 10);
            Console.WriteLine(14|19);
            Console.WriteLine(24|17);
            Console.WriteLine(29|11);
            Console.WriteLine(25 | 9);
            Console.WriteLine(19|8);





            Console.ReadLine();
        }
    }
}
