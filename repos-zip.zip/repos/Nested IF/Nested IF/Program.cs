﻿

Console.Title = "AHMED";

// ATM Mini project


Console.Write("Enter your pin : ");
string pin = Console.ReadLine();

int balance = 100000;

if (pin == "1234")
{
    Console.WriteLine("1.Balance\n2.Widhraw\n3.Deposit");
    string demand = Console.ReadLine();


    if (demand == "1")
    {
        Console.WriteLine($"Your balance is {balance:C0}");
    }



     else if (demand == "2")
     { 
        Console.Write("Enter widhraw amount : ");
        int widhraw = Convert.ToInt32(Console.ReadLine());

        if (widhraw >= 0)
        {
            if (widhraw <= balance )
            { Console.WriteLine($"{balance}\n{widhraw}");
                Console.WriteLine("Widhraw successful.");

                int remain = balance - widhraw;
                Console.Write($"Your remaining balance is {remain:C2}");
            }
            else { Console.WriteLine("Enough balance."); }
        }
        else { Console.WriteLine("Invalid amount."); }



     }

    else if (demand == "3")
    {
        Console.WriteLine();
    }
}

else
{
    Console.WriteLine(" Wrong pin Access denied.");
}