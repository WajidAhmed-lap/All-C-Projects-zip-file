
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Age_Calc
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ahmed";

            /*byte monthsInYear = 12;
            ushort daysInYear = 365;
            ushort hourInYear = 8760;


            Console.Write("Enter age in years : ");
            byte year = Convert.ToByte(Console.ReadLine());
            //  ===========> 10   

            byte months = Convert.ToByte(monthsInYear * year); 
            Console.WriteLine($"Age  in  months : {months}");
            // =========== 120

            ushort days = Convert.ToUInt16(daysInYear * year);
            Console.WriteLine($"Age in Days : {days}");
            // ===========>  3650

            int hour = Convert.ToInt32(hourInYear * year);
            Console.WriteLine($"Age in hours : {hour}");
            //   ==============>  87600










            Console.Write("Enter electricity consumption in kilowatt-hours : ");
            byte kh = Convert.ToByte(Console.ReadLine());
            //  10

            int watt_hour = kh*1000;
            Console.WriteLine($"Electricity consumption in watt-hours : {watt_hour}");
            // ==========> 10000








            Console.Write("Enter the number of electricity units consumed : \a");
            byte units = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Your bill is printing wait for 5 Sec.....");
            //=============>  75
            Console.Beep(32767,5000);

            ushort bill = Convert.ToUInt16(units * 15); 
            Console.WriteLine($"Total electricity bill : {bill}");
            //  =============>  1125







            ushort kgInTone = 1000;
            int gramInTone = 1000000;

            Console.Write("Enter the weight of cargo in tones : ");
            byte tones = Convert.ToByte(Console.ReadLine());
            //===========>   10

            ushort kg = Convert.ToUInt16(tones*kgInTone);
            Console.WriteLine($"Weight in Kilograms : {kg}");
            //  =============>    10000

            int grams = Convert.ToInt32(gramInTone*tones);
            Console.WriteLine($"Weight in grams : {grams}");
            // ===========>   10000000*/








            ushort fuelInML = 1000;
            double fuelInGLL = 0.264172;

            Console.Write("Enter fuel amount in litters : ");
            byte fuel = Convert.ToByte(Console.ReadLine());
            // ==========>  10

            ushort millilitters = Convert.ToUInt16(fuelInML*fuel);
            Console.WriteLine($"Fuel in millilitters : {millilitters}");
            //  =============>   10000

            double gallons = Convert.ToDouble(fuelInGLL*fuel);
            Console.WriteLine($"Fuel in gallons : {gallons:F6}");
            // =========>  2.641720

                





            Console.ReadLine();
        }
    }
}
