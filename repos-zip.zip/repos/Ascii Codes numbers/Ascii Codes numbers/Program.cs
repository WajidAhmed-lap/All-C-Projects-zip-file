using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ascii_Codes_numbers
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.Title = "...";


            //              Backwards


            /* Console.WriteLine("Write a program that takes a character input from the user and asks for the number of characters to shift backwards.");
             Console.WriteLine("====================================================================================================================");
             Console.Write("Enter a character ");
             char cha = Convert.ToChar(Console.ReadLine());

             ushort nm = Convert.ToUInt16(cha);

             Console.Write("Enter the number of character to shift backwards.");
             byte shift = Convert.ToByte(Console.ReadLine());

             ushort back = Convert.ToUInt16(nm-shift);

             char next = Convert.ToChar(back);

             Console.WriteLine($"The previous character before is : {next}");*/



            //              Next 



            Console.WriteLine("Write a program that takes a character input from the user and asks for the number of characters to shift backwards.");
            Console.WriteLine("====================================================================================================================");
            Console.Write("Enter a character ");
            char cha1 = Convert.ToChar(Console.ReadLine());

            ushort nm1 = Convert.ToUInt16(cha1);

            Console.Write("Enter the number of character to shift backwards.");
            byte shift1 = Convert.ToByte(Console.ReadLine());

            ushort back1 = Convert.ToUInt16(nm1 + shift1);

            char next1 = Convert.ToChar(back1);

            Console.WriteLine($"The previous character before is : {next1}");



            Console.ReadLine();
        }
    }
}
