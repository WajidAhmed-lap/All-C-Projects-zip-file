﻿

Console.Title = "Ahmed";

Console.Write("Enter your units : ");
int units = Convert.ToInt32(Console.ReadLine());

int amount = 0;

if (units >= 1 && units <= 100)
{
    amount = units * 5;

    Console.WriteLine($"{units} * 5 = {amount}");
}

else if (units >= 101 && units <= 200)
{

    Console.WriteLine("100 \t* \t5 \t= \t500");
    Console.WriteLine($"{units - 100}\t*  \t7 \t= \t{(units - 100) * 7}") ;
    Console.WriteLine("                         =========") ;


    Console.WriteLine($"\t\t\t{ (amount = 100 * 5 + (units - 100) * 7)}");
}
else if (units >= 201 && units <= 300)
{

    Console.WriteLine("100 \t* \t5 \t= \t500");
    Console.WriteLine("100 \t* \t7 \t= \t700");
    Console.WriteLine($"{units - 200}\t*  \t10 \t= \t{(units - 200) * 10}") ;
    Console.WriteLine("                         =========") ;


    Console.WriteLine($"\t\t\t{ (amount = 100 * 5 + 100 * 7 + (units - 200) * 10)}");
}


else if (units >= 301)
{
    Console.WriteLine("100 \t* \t5 \t= \t500\n100 \t* \t7 \t= \t700\n100 \t* \t10 \t= \t1000");
    Console.WriteLine($"{units - 300} \t* \t\t= \t{(units - 300)* 15}");

    Console.WriteLine("\t\t=====================================");

    Console.WriteLine($"\t\t\t{amount = 100 * 5 + 100 * 7 + 100 * 10 + (units - 300) * 15}");
}