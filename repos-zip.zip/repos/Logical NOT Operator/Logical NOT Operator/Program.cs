using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical_NOT_Operator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "...";


            byte a = 10;
            byte b = 15;
            byte c = 20;
            byte d = 25;


            Console.WriteLine(!(a != 5));
            //                     1 > 0 Convert into Opposite
            //  Real answer is 1=True bute after using NOT cmd then 0=False
            Console.WriteLine(!(b != 15));
            //                  0 > 1 
            //                  False |NOT| True
            Console.WriteLine(!(c != 20));
            //                  0 > 1
            //                  False NOT True 
            Console.WriteLine(! (d != 35));
            //                      1 > 0
            //                      True NOT False


            Console.ReadLine();
        }
    }
}
