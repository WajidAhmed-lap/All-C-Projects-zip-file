using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Macth_Details
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ahmed";
            //Team One Data
            Console.WriteLine("                           Now you are entering team 1 data"); 
            Console.Write("Please enter your team 1 name : ");
            string team1name = Console.ReadLine();

            Console.Write("Enter your Number of Macthes : ");
            byte macthNumber = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Number of Winning : ");
            byte winningNumbers = Convert.ToByte(Console.ReadLine());

            Console.Write("Number of Losing : ");
            byte losingNumber = Convert.ToByte(Console.ReadLine());

            Console.Write("NR Numbers : ");
            byte nrNumbers = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter your Points : ");
            byte pointsNumbers = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Net Run Rate : ");
            float netRunRate = Convert.ToSingle(Console.ReadLine());
            Console.Clear();

            //Team 2 Data
            Console.WriteLine("                           Now you are entering team 2 data");
            Console.Write("Please enter your team 2 name : ");
            string team2name = Console.ReadLine();

            Console.Write("Enter your Number of Macthes : ");
            byte macthNumber2 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Number of Winning : ");
            byte winningNumbers2 = Convert.ToByte(Console.ReadLine());

            Console.Write("Number of Losing : ");
            byte losingNumber2 = Convert.ToByte(Console.ReadLine());

            Console.Write("NR Numbers : ");
            byte nrNumbers2 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter your Points : ");
            byte pointsNumbers2 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Net Run Rate : ");
            float netRunRate2 = Convert.ToSingle(Console.ReadLine());
            Console.Clear();

            //Team 3 Data 
            Console.WriteLine("                           Now you are entering team 3 data");
            Console.Write("Please enter your team 3 name : ");
            string team3name = Console.ReadLine();

            Console.Write("Enter your Number of Macthes : ");
            byte macthNumber3 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Number of Winning : ");
            byte winningNumbers3 = Convert.ToByte(Console.ReadLine());

            Console.Write("Number of Losing : ");
            byte losingNumber3 = Convert.ToByte(Console.ReadLine());

            Console.Write("NR Numbers : ");
            byte nrNumbers3 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter your Points : ");
            byte pointsNumbers3 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Net Run Rate : ");
            float netRunRate3 = Convert.ToSingle(Console.ReadLine());
            Console.Clear();

            //Team 4 Data
            Console.WriteLine("                           Now you are entering team 4 data");
            Console.Write("Please enter your team 4 name : ");
            string team4name = Console.ReadLine();

            Console.Write("Enter your Number of Macthes : ");
            byte macthNumber4 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Number of Winning : ");
            byte winningNumbers4 = Convert.ToByte(Console.ReadLine());

            Console.Write("Number of Losing : ");
            byte losingNumber4 = Convert.ToByte(Console.ReadLine());

            Console.Write("NR Numbers : ");
            byte nrNumbers4 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter your Points : ");
            byte pointsNumbers4 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Net Run Rate : ");
            float netRunRate4 = Convert.ToSingle(Console.ReadLine());
            Console.Clear();

            //Team 5 Data
            Console.WriteLine("                           Now you are entering team 5 data");
            Console.Write("Please enter your team 5 name : ");
            string team5name = Console.ReadLine();

            Console.Write("Enter your Number of Macthes : ");
            byte macthNumber5 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Number of Winning : ");
            byte winningNumbers5 = Convert.ToByte(Console.ReadLine());

            Console.Write("Number of Losing : ");
            byte losingNumber5 = Convert.ToByte(Console.ReadLine());

            Console.Write("NR Numbers : ");
            byte nrNumbers5 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter your Points : ");
            byte pointsNumbers5 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Net Run Rate : ");
            float netRunRate5 = Convert.ToSingle(Console.ReadLine());
            Console.Clear();

            //Team 6 Data
            Console.WriteLine("                           Now you are entering team 6 data");
            Console.Write("Please enter your team 6 name : ");
            string team6name = Console.ReadLine();

            Console.Write("Enter your Number of Macthes : ");
            byte macthNumber6 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Number of Winning : ");
            byte winningNumbers6 = Convert.ToByte(Console.ReadLine());

            Console.Write("Number of Losing : ");
            byte losingNumber6 = Convert.ToByte(Console.ReadLine());

            Console.Write("NR Numbers : ");
            byte nrNumbers6 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter your Points : ");
            byte pointsNumbers6 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Net Run Rate : ");
            float netRunRate6 = Convert.ToSingle(Console.ReadLine());
            Console.Clear();

            //Team 7 Data
            Console.WriteLine("                           Now you are entering team 7 data");
            Console.Write("Please enter your team 7 name : ");
            string team7name = Console.ReadLine();

            Console.Write("Enter your Number of Macthes : ");
            byte macthNumber7 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Number of Winning : ");
            byte winningNumbers7 = Convert.ToByte(Console.ReadLine());

            Console.Write("Number of Losing : ");
            byte losingNumber7 = Convert.ToByte(Console.ReadLine());

            Console.Write("NR Numbers : ");
            byte nrNumbers7 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter your Points : ");
            byte pointsNumbers7 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Net Run Rate : ");
            float netRunRate7 = Convert.ToSingle(Console.ReadLine());
            Console.Clear();

            //Team 8 Data
            Console.WriteLine("                           Now you are entering team 8 data");
            Console.Write("Please enter your team 8 name : ");
            string team8name = Console.ReadLine();

            Console.Write("Enter your Number of Macthes : ");
            byte macthNumber8 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Number of Winning : ");
            byte winningNumbers8 = Convert.ToByte(Console.ReadLine());

            Console.Write("Number of Losing : ");
            byte losingNumber8 = Convert.ToByte(Console.ReadLine());

            Console.Write("NR Numbers : ");
            byte nrNumbers8 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter your Points : ");
            byte pointsNumbers8 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Net Run Rate : ");
            float netRunRate8 = Convert.ToSingle(Console.ReadLine());
            Console.Clear();

            //Team 9 Data
            Console.WriteLine("                           Now you are entering team 9 data");
            Console.Write("Please enter your team 9 name : ");
            string team9name = Console.ReadLine();

            Console.Write("Enter your Number of Macthes : ");
            byte macthNumber9 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Number of Winning : ");
            byte winningNumbers9 = Convert.ToByte(Console.ReadLine());

            Console.Write("Number of Losing : ");
            byte losingNumber9 = Convert.ToByte(Console.ReadLine());

            Console.Write("NR Numbers : ");
            byte nrNumbers9 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter your Points : ");
            byte pointsNumbers9 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Net Run Rate : ");
            float netRunRate9 = Convert.ToSingle(Console.ReadLine());
            Console.Clear();

            //Team 10 Data
            Console.WriteLine("                           Now you are entering team 10 data");
            Console.Write("Please enter your team 10 name : ");
            string team10name = Console.ReadLine();

            Console.Write("Enter your Number of Macthes : ");
            byte macthNumber10 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Number of Winning : ");
            byte winningNumbers10 = Convert.ToByte(Console.ReadLine());

            Console.Write("Number of Losing : ");
            byte losingNumber10 = Convert.ToByte(Console.ReadLine());

            Console.Write("NR Numbers : ");
            byte nrNumbers10 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter your Points : ");
            byte pointsNumbers10 = Convert.ToByte(Console.ReadLine());

            Console.Write("Enter Net Run Rate : ");
            float netRunRate10 = Convert.ToSingle(Console.ReadLine());
            Console.Clear();

















             Console.BackgroundColor = ConsoleColor.Cyan;
             Console.Clear();

             Console.SetCursorPosition(10,5);
             Console.BackgroundColor = ConsoleColor.White;
             Console.ForegroundColor = ConsoleColor.Red;
             Console.WriteLine("                                  WORLD CUP 2026 POINTS TABLE                                   ");

             Console.SetCursorPosition(10,7);
             Console.BackgroundColor = ConsoleColor.Cyan;
             Console.ForegroundColor = ConsoleColor.Green;
             Console.WriteLine("------------------------------------------------------------------------------------------------");

             Console.SetCursorPosition(55,8);
             Console.ForegroundColor = ConsoleColor.White;
             Console.WriteLine("POINTS");

             Console.SetCursorPosition(10,10);
             Console.BackgroundColor = ConsoleColor.Cyan;
             Console.ForegroundColor = ConsoleColor.Green;
             Console.WriteLine("------------------------------------------------------------------------------------------------");

             Console.ForegroundColor= ConsoleColor.Black;
             Console.SetCursorPosition(10,11);
             Console.Write("Sno.          Teams               M          W          L          NR          PT          N R R");

             //Team One

             Console.ForegroundColor = ConsoleColor.White;
             Console.SetCursorPosition(10,12);
             Console.Write("1");
             Console.SetCursorPosition(24,12);
             Console.Write($"{team1name}");
             Console.CursorLeft = 44;
             Console.Write($"{macthNumber}");
             Console.CursorLeft = 55;
             Console.Write($"{winningNumbers}");
             Console.CursorLeft = 66;
             Console.ForegroundColor = ConsoleColor.Red;
             Console.Write($"{losingNumber}");
             Console.ForegroundColor = ConsoleColor.White;
             Console.CursorLeft = 77;
             Console.Write($"{nrNumbers}");
             Console.CursorLeft = 89;
             Console.Write($"{pointsNumbers}");
             Console.CursorLeft = 101;
             Console.Write($"{netRunRate}");

             // Team Two

             Console.ForegroundColor = ConsoleColor.White;
             Console.SetCursorPosition(10, 13);
             Console.Write("2");
             Console.SetCursorPosition(24, 13);
             Console.Write($"{team2name}");
             Console.CursorLeft = 44;
             Console.Write($"{macthNumber2}");
             Console.CursorLeft = 55;
             Console.Write($"{winningNumbers2}");
             Console.CursorLeft = 66;
             Console.ForegroundColor = ConsoleColor.Red;
             Console.Write($"{losingNumber2}");
             Console.CursorLeft = 77;
             Console.ForegroundColor = ConsoleColor.White;
             Console.Write($"{nrNumbers2}");
             Console.CursorLeft = 89;
             Console.Write($"{pointsNumbers2}");
             Console.CursorLeft = 101;
             Console.Write($"{netRunRate2}");

             //Team Three

             Console.ForegroundColor = ConsoleColor.White;
             Console.SetCursorPosition(10,14);
             Console.Write("3");
             Console.SetCursorPosition(24,14);
             Console.Write($"{team3name}");
             Console.CursorLeft = 44;
             Console.Write($"{macthNumber3}");
             Console.CursorLeft = 55;
             Console.Write($"{winningNumbers3}");
             Console.CursorLeft = 66;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write($"{losingNumber3}");
             Console.CursorLeft = 77;
             Console.ForegroundColor = ConsoleColor.White;
             Console.Write($"{nrNumbers3}");
             Console.CursorLeft = 89;
             Console.Write($"{pointsNumbers3}");
             Console.CursorLeft = 101;
             Console.Write($"{netRunRate3}");

              //Team Four

             Console.ForegroundColor = ConsoleColor.White;
             Console.SetCursorPosition(10,15);
             Console.Write("4");
             Console.SetCursorPosition(24,15);
             Console.Write($"{team4name}");
             Console.CursorLeft = 44;
             Console.Write($"{macthNumber4}");
             Console.CursorLeft = 55;
             Console.Write($"{winningNumbers4}");
             Console.CursorLeft = 66;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write($"{losingNumber4}");
             Console.CursorLeft = 77;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($"{nrNumbers4}");
             Console.CursorLeft = 89;
             Console.Write($"{pointsNumbers4}");
             Console.CursorLeft = 101;
             Console.Write($"{netRunRate4}");

              //Team Five

             Console.ForegroundColor = ConsoleColor.White;
             Console.SetCursorPosition(10,16);
             Console.Write("5");
             Console.SetCursorPosition(24,16);
             Console.Write("{0}",team5name);
             Console.CursorLeft = 44;
             Console.Write("{0}",macthNumber5);
             Console.CursorLeft = 55;
             Console.Write("{0}",winningNumbers5);
             Console.CursorLeft = 66;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("{0}",losingNumber5);
             Console.CursorLeft = 77;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("{0}",nrNumbers5);
             Console.CursorLeft = 89;
             Console.Write("{0}",pointsNumbers5);
             Console.CursorLeft = 101;
             Console.Write("{0}",netRunRate5);

              //Team Six

             Console.ForegroundColor = ConsoleColor.White;
             Console.SetCursorPosition(10,17);
             Console.Write("6");
             Console.SetCursorPosition(24,17);
             Console.Write("{0}",team6name);
             Console.CursorLeft = 44;
             Console.Write("{0}",macthNumber6);
             Console.CursorLeft = 55;
             Console.Write("{0}",winningNumbers5);
             Console.CursorLeft = 66;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("{0}",losingNumber5);
             Console.CursorLeft = 77;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("{0}",nrNumbers6);
             Console.CursorLeft = 89;
             Console.Write("{0}",pointsNumbers6);
             Console.CursorLeft = 101;
             Console.Write("{0}",netRunRate6);

              //Team Seven

             Console.ForegroundColor = ConsoleColor.White;
             Console.SetCursorPosition(10,18);
             Console.Write("7");
             Console.SetCursorPosition(24,18);
             Console.Write("{0}",team7name);
             Console.CursorLeft = 44;
             Console.Write($"{macthNumber7}");
             Console.CursorLeft = 55;
             Console.Write($"{winningNumbers7}");
             Console.CursorLeft = 66;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write($"{losingNumber7}");
             Console.CursorLeft = 77;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($"{nrNumbers7}");
             Console.CursorLeft = 89;
             Console.Write($"{pointsNumbers7}");
             Console.CursorLeft = 101;
             Console.Write($"{netRunRate7}");

              //Team Eight

             Console.ForegroundColor = ConsoleColor.White;
             Console.SetCursorPosition(10,19);
             Console.Write("8");
             Console.SetCursorPosition(24,19);
             Console.Write("{0}",team8name);
             Console.CursorLeft = 44;
             Console.Write("{0}",macthNumber8);
             Console.CursorLeft = 55;
             Console.Write("{0}",winningNumbers8);
             Console.CursorLeft = 66;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("{0}",losingNumber8);
             Console.CursorLeft = 77;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("{0}",nrNumbers8);
             Console.CursorLeft = 89;
             Console.Write("{0}",pointsNumbers8);
             Console.CursorLeft = 101;
             Console.Write("{0}",netRunRate8);

              //Team Nine

             Console.ForegroundColor = ConsoleColor.White;
             Console.SetCursorPosition(10,20);
             Console.Write("9");
             Console.SetCursorPosition(24,20);
             Console.Write("{0}",team9name);
             Console.CursorLeft = 44;
             Console.Write("{0}",macthNumber9);
             Console.CursorLeft = 55;
             Console.Write("{0}",winningNumbers9);
             Console.CursorLeft = 66;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("{0}",losingNumber9);
             Console.CursorLeft = 77;
             Console.ForegroundColor = ConsoleColor.White;
            Console.Write("{0}",nrNumbers9);
             Console.CursorLeft = 89;
             Console.Write("{0}",pointsNumbers9);
             Console.CursorLeft = 101;
             Console.Write("{0}",netRunRate9);

              //Team Ten

             Console.ForegroundColor = ConsoleColor.White;
             Console.SetCursorPosition(10,21);
             Console.Write("10");
             Console.SetCursorPosition(24,21);
             Console.Write("{0}",team10name);
             Console.CursorLeft = 44;
             Console.Write("{0}",macthNumber10);
             Console.CursorLeft = 55;
             Console.Write("{0}",winningNumbers10);
             Console.CursorLeft = 66;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("{0}",losingNumber10);
             Console.CursorLeft = 77;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("{0}",nrNumbers10);
             Console.CursorLeft = 89;
             Console.Write("{0}",pointsNumbers10);
             Console.CursorLeft = 101;
             Console.Write("{0}",netRunRate10);

              Console.SetCursorPosition(10,24);
              Console.BackgroundColor = ConsoleColor.White;
              Console.ForegroundColor = ConsoleColor.Red;
              Console.WriteLine("                                  TOP 4 TEAMS QUALIFY FOR SEMI FINAL                                  ");

              Console.SetCursorPosition(10,26);
              Console.WriteLine("                                  ICC MEN'S T20 WC 2026                                               ");



            Console.ReadLine();
        }
    }
}
