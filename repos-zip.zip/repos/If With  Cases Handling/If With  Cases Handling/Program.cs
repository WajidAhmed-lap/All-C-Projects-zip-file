﻿using System.ComponentModel.Design;

Console.Title = "AHMED";

Console.WriteLine("                     Q No : 1 ");

Console.Write("\n\n\nEnter any vowel letter in any case : ");
char vowel = Convert.ToChar(Console.ReadLine());

char lowerCase = char.ToLower(vowel);

if (lowerCase == 'a' || lowerCase == 'e' || lowerCase == 'i' || lowerCase == 'o' || lowerCase == 'u'  )
{
    Console.WriteLine($"This is {lowerCase} vowel letter.");
}

else {

    Console.WriteLine($"This is {lowerCase} not vowel.");
}
Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("             Q No : 2  ");

Console.Write("\n\n\nEnter any day name : ");
string day = Console.ReadLine();

if (day.ToLower() == "monday" || day.ToLower() == "tuesday" || day.ToLower() == "wednesday" || day.ToLower() == "thursday")
{
    Console.WriteLine("Working day.");
}

else if (day.ToLower() == "friday")
{ Console.WriteLine("Half day."); }

else if (day.ToLower() == "saturday" || day.ToLower()=="sunday")
{ Console.WriteLine("Holiday."); }
Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("             Q No 3 ");
Console.Write("\n\n\nare you agree with our term & condition : ");
string agree  = Console.ReadLine();

if (agree.ToLower() == "yes")
{
    Console.WriteLine("You agreed.");
}

else { Console.WriteLine("You disagreed."); }

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("                Q No : 4  ");

Console.Write("\n\n\nEnter your gender : ");
string gender = Console.ReadLine();

if (gender.ToLower() == "male")
{
    Console.WriteLine("You selected Male.");
}

else if (gender.ToLower() == "female")
{ Console.WriteLine("You selected Female."); }

else if (gender.ToLower() != "male" || gender.ToLower() != "female")
    { Console.WriteLine("You selected wrong option."); }

Console.ReadLine();
Console.Clear();


//================================================================

Console.WriteLine("         Q No : 5 ");

Console.Write("\n\n\nEnter the thing name which you want : ");
string product = Console.ReadLine();

if (product.ToLower() == "keyboard")
{ Console.WriteLine("keyboard price is Rs.1000"); }

else if  (product.ToLower() == "mouse")
{
    Console.WriteLine("Mouse price is Rs.2000");
}

else if (product.ToLower() == "ram")
{
    Console.WriteLine("Ram price is Rs.3000");
}

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("                 Q No : 6");

Console.WriteLine("\n\n\nEnter character : ");
char charr = Convert.ToChar(Console.ReadLine());

if (charr == 'c' || charr == 'C')
{ Console.WriteLine("C#."); }

else { Console.WriteLine("Invalid course."); }

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("             Q No : 7 " );

Console.WriteLine("\n\n\nEnter python in different format : ");
string sCourse = Console.ReadLine();

if (sCourse.ToLower() == "python")
{
    Console.WriteLine("Valid Course.");
}

else { Console.WriteLine("Invalid."); }

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("             Q No : 8  ");


Console.WriteLine("\n\n\nEnter our country name in any format : ");
string country = Console.ReadLine();

if (country.ToLower() == "pakistan")
{
    Console.WriteLine("Valid Country Name.");
}

else { Console.WriteLine("Invalid Country Name."); }


Console.ReadLine();
Console.Clear();


//================================================================

Console.WriteLine("             Q No : 9 ");

Console.WriteLine("\n\n\nEnter ufone name in any format : ");
string company = Console.ReadLine();

if (company.ToLower() == "ufone")
{
    Console.WriteLine("Valid company name.");
}

else { Console.WriteLine("Invalid Company Name."); }

Console.ReadLine();
Console.Clear();

//================================================================