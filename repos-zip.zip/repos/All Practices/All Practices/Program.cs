using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace All_Practices
{
    internal class Program
    {
        static void Main(string[] args)
        {

            /*Console.WriteLine(1000 & 500);
            Console.WriteLine(1000 | 500);
            Console.WriteLine(1000 ^ 500);

            Console.WriteLine(sizeof(char));
            Console.WriteLine(sizeof(byte));
            Console.WriteLine(byte.MinValue);
            Console.WriteLine(byte.MaxValue);
            Console.WriteLine(sizeof(sbyte));
            Console.WriteLine(sbyte.MinValue);
            Console.WriteLine(sbyte.MaxValue);
            Console.WriteLine(sizeof(ushort));
            Console.WriteLine(ushort.MinValue);
            Console.WriteLine(ushort.MaxValue);
            Console.WriteLine(sizeof(short));
            Console.WriteLine(short.MinValue);
            Console.WriteLine(short.MaxValue);
            Console.WriteLine(sizeof(uint));
            Console.WriteLine(uint.MinValue);
            Console.WriteLine(uint.MaxValue);
            Console.WriteLine(sizeof(int));
            Console.WriteLine(int.MinValue);
            Console.WriteLine(int.MaxValue);
            Console.WriteLine(sizeof(ulong));
            Console.WriteLine(ulong.MinValue);
            Console.WriteLine(ulong.MaxValue);
            Console.WriteLine(sizeof(long));
            Console.WriteLine(long.MinValue);
            Console.WriteLine(long.MaxValue);




            Console.WriteLine("Please write t if you want to  see triangle if wanna see circle write c ");
            char check = Convert.ToChar(Console.ReadLine());
            // c/t
            if (check == 'c')
            { Console.WriteLine("circle"); }
            else
            { Console.WriteLine("Invalid Character "); }


            Console.WriteLine("age ");
            byte age = Convert.ToByte(Console.ReadLine());

            if (age == 50)
            { Console.WriteLine("you are too late"); }

            if (age >= 18)
            { Console.WriteLine("now you are 18+"); }

            if (age <= 17)
            { Console.WriteLine("this is your school age "); }*/



            Console.WriteLine("Salam" == "HI" && 87 == 'a');
            Console.WriteLine(20 == 20 && "okay" == "okay");
            Console.WriteLine(20 != 25 && 10 != 20);
            Console.WriteLine('a' != 'a' && 9 != 9);
            Console.WriteLine(!(20 == 20));
            Console.WriteLine(!(20 != 20));
            Console.WriteLine(10 !=10||10==10);
            Console.WriteLine('a'&'a');
            Console.WriteLine('a'&'A');
            Console.WriteLine(10|10);







            Console.ReadLine();
        }
    }
}
