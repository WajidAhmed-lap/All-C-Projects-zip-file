using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Multiple__if__s__2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ahmed";

            //                  Q 1


            Console.WriteLine("Take a Character input and display values according to below given chart.");
            //  a , b , c , d

            char ch1 = Convert.ToChar(Console.ReadLine());


            if (ch1 == 'a')
            { Console.WriteLine("Apple"); }

            if (ch1 == 'b')
            { Console.WriteLine("Banana"); }

            if (ch1 == 'c')
            { Console.WriteLine("Cherry"); }

            if (ch1 == 'd')
            { Console.WriteLine("Date"); }
            Console.ReadLine();
            Console.Clear();

            //==========================================>

            //          Q : 2

            Console.WriteLine("Take a Character input and display values according to below given chart.");
            //  e , f , g , h

            char ch2 = Convert.ToChar(Console.ReadLine());


            if (ch2 == 'e')
            { Console.WriteLine("Elephant"); }

            if (ch2 == 'f')
            { Console.WriteLine("Frog"); }

            if (ch2 == 'g')
            { Console.WriteLine("Giraffe"); }

            if (ch2 == 'H')
            { Console.WriteLine("Hippo"); }
            Console.ReadLine();

            Console.Clear();

            //==========================================>

            //          Q : 3

            Console.WriteLine("Take a number input and display values according to below given chart.");
            //  10 , 20 , 30 , 40

            byte  nm1 = Convert.ToByte(Console.ReadLine());


            if (nm1 == 10)
            { Console.WriteLine("Ten"); }
 
            if (nm1 ==20)
            { Console.WriteLine("Twenty "); }
 
            if (nm1 == 30)
            { Console.WriteLine("Thirty"); }
 
            if (nm1 ==40)
            { Console.WriteLine("Fourty"); }
            Console.ReadLine();

            Console.Clear();


            //==========================================>

            //          Q : 4

            Console.WriteLine("Take a number input and display values according to below given chart.");
            //  100 , 200 , 300 , 400

            short  nm2 = Convert.ToInt16(Console.ReadLine());


            if (nm2 == 100)
            { Console.WriteLine("One Hundred"); }
 
            if (nm2 ==200)
            { Console.WriteLine("Two Hundred"); }
 
            if (nm2 == 300)
            { Console.WriteLine("Three Hundred"); }
 
            if (nm2 ==400)
            { Console.WriteLine("Four Hundred"); }
            Console.ReadLine();

            Console.Clear();


            //==========================================>

            //      Q = 5

            Console.WriteLine("Take a string input and display values according to below  given chart.");
            
            //      dog , rose , apple , carrot 

            string st1 = Console.ReadLine();

            if (st1 == "dog")
            { Console.WriteLine("Animal"); }

            if (st1 == "rose")
            { Console.WriteLine("Flower"); }

            if (st1 == "apple")
            { Console.WriteLine("Fruit"); }

            if (st1 == "carrot")
            { Console.WriteLine("Vegetable"); }
            Console.ReadLine();

            Console.Clear();
            //======================================================

            //      Q = 6

            Console.WriteLine("Take a string input and display values according to below  given chart.");
            
            //      soft , sweet , round , red

            string st2 = Console.ReadLine();

            if (st2 == "soft ")
            { Console.WriteLine("Texture"); }

            if (st2 == "sweet")
            { Console.WriteLine("Taste"); }

            if (st2 == "round")
            { Console.WriteLine("Shape"); }

            if (st2 == "red")
            { Console.WriteLine("Colour"); }
            Console.ReadLine();

            Console.Clear();


            //==================================================

            // Q : 7 


            Console.WriteLine("Take a character input and display values according to below given chart.");
            //      j , f , m , a

            char ch3 = Convert.ToChar(Console.ReadLine());


            if (ch3 == 'j')
            { Console.WriteLine("January"); }

            if (ch3 == 'f')
            { Console.WriteLine("Fabruary"); }

            if (ch3 == 'm')
            { Console.WriteLine("March"); }

            if (ch3 == 'a')
            { Console.WriteLine("April"); }
            Console.ReadLine();

            Console.Clear();

            //==============================>>

            //          Q : 8

            Console.WriteLine("Take a number input and display values according to below given chart.");
            //  1 , 2 , 3 , 4

            byte nm3 = Convert.ToByte(Console.ReadLine());


            if (nm3 == 1)
            { Console.WriteLine("One"); }

            if (nm3 == 2)
            { Console.WriteLine("Two"); }

            if (nm3 == 3)
            { Console.WriteLine("Three"); }

            if (nm3 == 4)
            { Console.WriteLine("Four"); }
            Console.ReadLine();

            Console.Clear();

            //==========================================>


            // Q nO 9 

            Console.WriteLine("Take a floaing point input and display values according to below given chart.");
            
            // 1.1 , 2.2 , 3.3 , 4.4

            float point = Convert.ToSingle(Console.ReadLine());

            if (point == 1.1F)
            { Console.WriteLine("One Point One"); }

            if (point == 2.2F)
            { Console.WriteLine("Two Point Two"); }

            if (point == 3.3F)
            { Console.WriteLine("Three Point Three"); }

            if (point == 4.4F)
            { Console.WriteLine("Four Point Four"); }
            Console.ReadLine();

            Console.Clear();

            //======================================>

            // Q nO 10 

            Console.WriteLine("Take a floaing point input and display values according to below given chart.");
            
            // 5.5 , 6.6 , 7.7 , 8.8

            float point1 = Convert.ToSingle(Console.ReadLine());

            if (point1 == 5.5F)
            { Console.WriteLine("Five Point Five"); }

            if (point1 == 6.6F)
            { Console.WriteLine("Six Point Six"); }

            if (point1 == 7.7F)
            { Console.WriteLine("Seven Point Seven"); }

            if (point1 == 8.8F)
            { Console.WriteLine("Eight Point Eight"); }
            Console.ReadLine();

            Console.Clear();

            //======================================>

            //  Q No : 11

            Console.WriteLine("Take a number input and display values according to below given chart.");

            //  1 , 2 , 3 , 4

            byte nm4= Convert.ToByte(Console.ReadLine());

            if (nm4 == 1)
            { Console.WriteLine("Monday"); }

            if (nm4 == 2)
            { Console.WriteLine("Tuesday"); }

            if (nm4 == 3)
            { Console.WriteLine("Wednesday"); }

            if (nm4 == 4)
            { Console.WriteLine("Thursday"); }

            if (nm4 == 5)
            { Console.WriteLine("Friday"); }
            Console.ReadLine();

            Console.Clear();

            //==============================//

            //  Q No : 12

            Console.WriteLine("Take a number input and display values according to below given chart.");

            //  11 , 22 , 33 , 44

            byte nm5= Convert.ToByte(Console.ReadLine());

            if (nm5 == 11)
            { Console.WriteLine("Eleven"); }

            if (nm5 == 22)
            { Console.WriteLine("Twenty Two"); }

            if (nm5 == 33)
            { Console.WriteLine("Thirty Three"); }

            if (nm5 == 44)
            { Console.WriteLine("Fourty Four"); }

            if (nm4 == 55)
            { Console.WriteLine("Fifty Five"); }
            Console.ReadLine();

            Console.Clear();

            //==============================//

            //      Q 13 

            Console.WriteLine("Take a string input and display values according to below given chart.");

            // janauary , february , march , april

            string st3= Console.ReadLine();

            if (st3=="january")
            { Console.WriteLine(1); }

            if (st3=="february")
            { Console.WriteLine(2); }

            if (st3=="march")
            { Console.WriteLine(3); }

            if (st3=="april")
            { Console.WriteLine(4); }
            Console.ReadLine();

            Console.Clear();

            //============================||//

            // Q nO 14

            Console.WriteLine("Take a string input and display values according to below given chart.");

            // one , two , three , four

            string st4= Console.ReadLine();

            if (st4=="one")
            { Console.WriteLine(1); }

            if (st4=="two")
            { Console.WriteLine(2); }

            if (st4=="three")
            { Console.WriteLine(3); }

            if (st4=="four")
            { Console.WriteLine(4); }
            Console.ReadLine();

            Console.Clear();


            //============================//

            Console.WriteLine("Thanks For Choosing us ( *_* )");






























            Console.ReadLine();
        }
    }
}
