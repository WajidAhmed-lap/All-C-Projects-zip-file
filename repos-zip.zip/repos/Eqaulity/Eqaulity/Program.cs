using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eqaulity
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string str1 = "html";
            string str2 = "CSharp";
            string str3 = "DOT NET";
                            //      Equality 
            Console.WriteLine(str1=="html");            // True
            Console.WriteLine(str2==str1);              // false
            Console.WriteLine(str2==str3);              // false
            Console.WriteLine(str1== "HTML");           // False
            Console.WriteLine(str2 == "C#");            // false
            Console.WriteLine(str3 == "DOT NET");       // True
            Console.WriteLine(str3==".NET");            // false 
            Console.WriteLine(str3=="C#.NET");          // false
            Console.WriteLine(str1==str3);              // false
            Console.WriteLine(str1=="C#");              // false
            Console.WriteLine("DOT NET "== "C#" );      // false
            Console.WriteLine(str3== "dot net");        // false
            Console.WriteLine(str2=="c#");              // false
            Console.WriteLine(str2 == str3);            // false
            



            Console.ReadLine();
        }
    }
}
