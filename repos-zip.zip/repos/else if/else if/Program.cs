using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace else_if
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ahmed";


            Console.WriteLine("Enter Operator name which you wanna know about");

            char ope= Convert.ToChar(Console.ReadLine());

            if(ope=='a')
            { Console.WriteLine("Arithmetic");
                Console.WriteLine("IF you wanna know more then press enter");
                Console.ReadLine();
                Console.WriteLine("1. Additional" +
                    "              2. Subtraction" +
                    "              3. Multiplication" +
                    "              4. Divid");

            }
            Console.ReadLine() ;
            Console.Clear();

            //=========================================================================

            Console.WriteLine("Enter the colour name red then you can see it" +
                "and after five seconds it will be set as default ");
            string colour = Console.ReadLine();

            if (colour=="red")
            { Console.BackgroundColor=ConsoleColor.Red;
                Console.Clear();
                Console.Beep(100, 5000);

                Console.BackgroundColor = ConsoleColor.Black;
                Console.Clear();
            }

            else if (colour=="blue")
            { Console.BackgroundColor=ConsoleColor.Blue;
                Console.Clear();
                Console.Beep(100, 5000);

                Console.BackgroundColor = ConsoleColor.Black;
                Console.Clear();
            }

           else  if (colour == "green")
            {
                Console.BackgroundColor = ConsoleColor.Green;
                Console.Clear();
                Console.Beep(100,5000);

                Console.BackgroundColor = ConsoleColor.Black ;
                Console.Clear() ;
            }

            Console.ReadLine();
            Console.Clear();




            //=============================================================

            Console.WriteLine("Enter s for sindh,p for pujab,k for khyber pakhtunkhwa,b for balochistan");
            char province = Convert.ToChar(Console.ReadLine());


            if (province == 's')
            { Console.WriteLine("Sindh"); }

            else if (province=='p')
            { Console.WriteLine("Punjab "); }

            else if (province =='k')
            { Console.WriteLine("Khyber Pakhtunkhwa"); }    

            else if (province =='b')
            { Console.WriteLine("Balochistan"); }
            Console.ReadLine();
            Console.Clear();


            //============================================



            Console.WriteLine("Enter a for australia , b for bangladesh, c for canada , d for denmark");
            char country = Convert.ToChar(Console.ReadLine());


            if (country == 'a')
            { Console.WriteLine("Australia"); }

            else if (country == 'b')
            { Console.WriteLine("Bangladesh"); }

            else if (country == 'c')
            { Console.WriteLine("Canada"); }

            else if (country == 'd')
            { Console.WriteLine("Denmark"); }
            Console.ReadLine();
            Console.Clear();

            //=================================================

            Console.WriteLine("Enter number if number is 300 then mobilink , 313 then zong , 333 then warid");
            short number = Convert.ToInt16(Console.ReadLine());

            if (number == 300)
            { Console.WriteLine("Mobilink"); }

            else if (number==313)
            { Console.WriteLine("Zong"); }

            else if (number==333)
            { Console.WriteLine("Warid"); }

            //==================================


            Console.WriteLine("Enter Student name to getting their info");
            string student= Console.ReadLine();

            if(student =="ali")
            { Console.WriteLine("Ali ia a C# Student"); }

            else if(student =="asif")
            { Console.WriteLine("Asid ia a HTML Student"); }

            else if(student =="atif")
            { Console.WriteLine("Atif ia a Java Student"); }

            //===============================================================

            Console.WriteLine("Enter Company name to getting their info");
            string company= Console.ReadLine();

            if(company =="nokia")
            { Console.WriteLine("Windows"); }

            else if(company =="samsung")
            { Console.WriteLine("Android"); }

            else if(company =="iphone")
            { Console.WriteLine("iOS"); }

            //===============================================================


            Console.WriteLine("Take input yearsofExperience and display values according to below given chart.");

            short experience = Convert.ToInt16(Console.ReadLine());

            if (experience >= 15)
            { Console.WriteLine("Most Senior"); }

            else if (experience>=10)
            { Console.WriteLine("Senior"); }

            else if (experience >=5)
            { Console.WriteLine("Junior"); }

            else if (experience >=1)
            { Console.WriteLine("Most Junior"); }

            //==================================







            Console.ReadLine();
        }
    }
}
