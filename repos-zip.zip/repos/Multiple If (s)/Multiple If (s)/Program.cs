
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiple_If__s_
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ahmed";


            /*Console.Write("Take a character input and display values according to below given chart ." +
                "for sindh type s" +
                "for panjab type p" +
                "for khyber pakhtunkhwa type k" +
                "for balochistan type b :");

            char searching = Convert.ToChar(Console.ReadLine());
            //  s,p,k,b

            if (searching=='s')
            { Console.WriteLine("Sindh"); }
            if (searching == 'p')
            { Console.WriteLine("Panjab"); }
            if (searching == 'k')
            { Console.WriteLine("Khyber Pakhtunkhwa"); }
            if (searching == 'b')
            { Console.WriteLine("Balochistan"); }

            //==========================================================

            Console.Write("Take a character input and display values according to below given chart ." +
                "for Australia type a" +
                "for Bangladesh type b" +
                "for Canada type c" +
                "for Denmark type d :");

            char searching2 = Convert.ToChar(Console.ReadLine());
            //  a,b,c,d

            if (searching2 == 'a')
            { Console.WriteLine("Australia"); }
            if (searching2 == 'b')
            { Console.WriteLine("Bangladesh"); }
            if (searching2 == 'c')
            { Console.WriteLine("Canada"); }
            if (searching2 == 'd')
            { Console.WriteLine("Denmark"); }

            //==========================================================

            Console.Write("Take a number input and display values according to below given chart ." +
                "for Mobilink type 300" +
                "for Zong type 313" +
                "for Ufone type 333" +
                "for Telenor type 345 :"+
                "for Warid type 321 :");

            char searching3 = Convert.ToChar(Console.ReadLine());
            //  300,313,333,345,321

            if (searching3 == 300)
            { Console.WriteLine("Mobilink"); }
            if (searching3 == 313)
            { Console.WriteLine("Zong"); }
            if (searching3 == 333)
            { Console.WriteLine("Ufone"); }
            if (searching3 == 345)
            { Console.WriteLine("Telenor"); }
            if (searching3 == 321)
            { Console.WriteLine("Warid"); }

            //==========================================================

            Console.Write("Take a string input and display values according to below given chart ." +
                "for   type Mobilink" +
                "for 0313 type Zong" +
                "for 0333 type Ufone" +
                "for 0345 type Telenor :"+
                "for 0321 type Warid :");

            string searching1 = Console.ReadLine();
            //  mobilink,zong,ufone,telenor,warid

            if (searching1 == "mobilink")
            { Console.WriteLine("0300"); }
            if (searching1 == "zong")
            { Console.WriteLine("0313"); }
            if (searching1 == "Ufone")
            { Console.WriteLine("0333"); }
            if (searching1 == "telenor")
            { Console.WriteLine("0345"); }
            if (searching1 == "warid")
            { Console.WriteLine("0321"); }

            //==========================================================

            Console.Write("For getting info about student just " +
                "enter the name like ali , asif , atif");

            string searching4 = Console.ReadLine();
            //  ali,asif,atif

            if (searching4 == "ali")
            { Console.WriteLine("Ali is a C# Student"); }
            
            if (searching4 == "asif")
            { Console.WriteLine("Asif is a HTML Student"); }
            
            if (searching4 == "atif")
            { Console.WriteLine("atif is a Java Student"); }


            //==========================================================


            Console.Write("Take a company name input and display values according to below given chart ." +
                "for windows type nokia " +
                "for android type samsung" +
                "for ios type iphone");

            string searching5 = Console.ReadLine();
            //  nokia , samsung , iphone

            if (searching5 == "nokia")
            { Console.WriteLine("Windows"); }
            if (searching5 == "samsung")
            { Console.WriteLine("Android"); }
            if (searching5 == "iphone")
            { Console.WriteLine("iOS"); }


            //==========================================================
            Console.Write("Which course you are searching enter as this formate " +
                "DCBM , DIT , CIT ");

            string searching6 = Console.ReadLine();
            //      dcbm , dit , cit  

            if (searching6 == "dcbm")
            { Console.WriteLine("Faith Offering DCBM"); }
           
            if (searching6 == "dit")
            { Console.WriteLine("Faith Offering DIT"); }
           
            if (searching6 == "cit")
            { Console.WriteLine("Faith Offering CIT"); }

            //==========================================================
           

            Console.Write("Tell me which operator you wanna know about" +
                "like unary , binary , ternary");

            string searching7 = Console.ReadLine();
            //  Unary , binary , ternary

            if (searching7 == "unary")
            { Console.WriteLine("Unary deals with single operand"); }
            
            if (searching7 == "binary")
            { Console.WriteLine("binary deals with two operands"); }
            
            if (searching7 == "ternary")
            { Console.WriteLine("Ternary deals with three operands"); }


            //==========================================================

            Console.Write("Take username input and display values according" +
                "to below given chart. ");

            string searching8 = Console.ReadLine();
            //  admin , asif , atif

            if (searching8 == "admin")
            { Console.WriteLine("Welcom Admin"); }
                
            if (searching8 == "asif")
            { Console.WriteLine("Welcom Sub User"); }
                
            if (searching8 == "atif")
            { Console.WriteLine("Welcom Data Entry Operator"); }

            //==========================================================


            Console.Write("Take input yearofExperience and display values according" +
                "to below given chart.");

            byte searching9 = Convert.ToByte(Console.ReadLine());
            //  15 , 10 , 5 , 1

            if (searching9 >= 15)
            { Console.WriteLine("Most Senior"); }
            
            if (searching9 >= 10)
            { Console.WriteLine("Senior"); }
            
            if (searching9 >= 5)
            { Console.WriteLine("Junior"); }
            
            if (searching9 >= 1)
            { Console.WriteLine("Most Junior"); }

            //==========================================================


            Console.Write("Take input day Name and display values according to below given chart.");

            string searching11 = Console.ReadLine();
            //  monday ,tuesday , wednesday , thursday , friday , stuarday , sunday 

            if (searching11 == "monday")
            { Console.WriteLine("Working Day"); }

            if (searching11 == "tuesday")
            { Console.WriteLine("Working Day"); }

            if (searching11 == "wednesday")
            { Console.WriteLine("Working Day"); }

            if (searching11 == "thursday")
            { Console.WriteLine("Working Day"); }

            if (searching11 == "friday")
            { Console.WriteLine("Working Day"); }

            if (searching11 == "stuarday")
            { Console.WriteLine("Holiday"); }

            if (searching11 == "sunday")
            { Console.WriteLine("Holiday"); }


            //==========================================================

            Console.Write("Take operator name npur and display values according to below chart.");

            string searching12 = Console.ReadLine();
            //  Arithmetic , Logical , Relational

            if (searching12 == "arithmetic")
            { Console.WriteLine("Addition (+)" +
                                "Subtraction (-)" +
                                "Multiplicaion (*)" +
                                "Divide (/)" +
                                "Modulus (%)"); 
            }

            if (searching12 == "logical ")
            {
                Console.WriteLine("Logical AND ( && )" +
                                  "Logical OR ( || ) " +
                                  "Logical NOT ( ! )");
            }
                                    
            if (searching12 == "relational ")
            {
                Console.WriteLine("Greater than ( > )" +
                                  "Less than ( < ) " +
                                  "Less than or Equal ( <= )"+
                                  " Greater than or Equal ( >= )");
            }


            //==========================================================


            Console.Write("You can choose one colour of them red , blue , green ");

            string searching13 =Console.ReadLine();
            //  

            if (searching13 == "red")
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Clear();
             }
           
            if (searching13 == "blue")
            {
                Console.BackgroundColor = ConsoleColor.Blue;
                Console.Clear();
             }
           
            if (searching13 == "green")
            {
                Console.BackgroundColor = ConsoleColor.Green;
                Console.Clear();
             }
           



            //==========================================================*/


            Console.ReadLine();
        }
    }
}
