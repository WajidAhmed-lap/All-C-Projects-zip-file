﻿

using System.Diagnostics;
using System.Linq.Expressions;

Console.Title = "AHMED";
/*Console.Write("Enter a character : ");
char ch = Convert.ToChar(Console.ReadLine());

switch (ch)
{
    case 'a':
        Console.WriteLine("Accounting");
        break;
    default:
        Console.WriteLine("Wrong character.");
        break;


}

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enter 7 : ");
byte num = Convert.ToByte(Console.ReadLine());

switch(num)
{
    case 7:
        Console.WriteLine("Seven.");
        break;
    default:
        Console.WriteLine("Wrong number.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enter 3.14 : ");
float point = Convert.ToSingle(Console.ReadLine());

switch (point)
{
    case 3.14F:
        Console.WriteLine("Correct value.");
        break;
        default:
        Console.WriteLine("Wrong command.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================



Console.WriteLine("Enter One : ");
string nmInEng = Console.ReadLine();

switch (nmInEng)
{
    case "one":
        Console.WriteLine("1");
        break;
    default:
        Console.WriteLine("Wrong.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter true : ");
bool check = Convert.ToBoolean(Console.ReadLine());

switch (check)
{
    case true:
        Console.WriteLine("Married");
        break;
    default:
        Console.WriteLine("Out of option.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter P character : ");
char ch1 = Convert.ToChar(Console.ReadLine());

switch (ch1)
{
    case'P':
        Console.WriteLine("PHP");
        break;
    default:
        Console.WriteLine("Wrong character.");
        break;


}

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enter 9 : ");
byte num1 = Convert.ToByte(Console.ReadLine());

switch (num1)
{
    case 9:
        Console.WriteLine("Nine.");
        break;
    default:
        Console.WriteLine("Wrong number.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter 6.18 : ");
float point1 = Convert.ToSingle(Console.ReadLine());

switch (point1)
{
    case 6.18F:
        Console.WriteLine("Correct value.");
        break;
    default:
        Console.WriteLine("Wrong command.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter true : ");
bool check1 = Convert.ToBoolean(Console.ReadLine());

switch (check1)
{
    case true:
        Console.WriteLine("Educated.");
        break;
    default :
        Console.WriteLine("Wrong.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enter ten : ");
string nmInEng1 = Console.ReadLine();

switch (nmInEng1)
{
    case "ten":
        Console.WriteLine("10");
        break;
    default:
        Console.WriteLine("Wrong.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter M character : ");
char ch2 = Convert.ToChar(Console.ReadLine());

switch (ch2)
{
    case 'M':
        Console.WriteLine("MS Office.");
        break;
    default:
        Console.WriteLine("Wrong character.");
        break;


}

Console.ReadLine();
Console.Clear();

//================================================================



Console.WriteLine("Enter 10 : ");
byte num2 = Convert.ToByte(Console.ReadLine());

switch (num2)
{
    case 10:
        Console.WriteLine("Ten.");
        break;
    default:
        Console.WriteLine("Wrong number.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter 9.33 : ");
float point2 = Convert.ToSingle(Console.ReadLine());

switch (point2)
{
    case 9.33F:
        Console.WriteLine("Correct value.");
        break;
    default:
        Console.WriteLine("Wrong command.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enter true : ");
bool check2 = Convert.ToBoolean(Console.ReadLine());

switch (check2)
{
    case true:
        Console.WriteLine("Student.");
        break;
    default:
        Console.WriteLine("Out of option.");
        break;
}

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter fifteen : ");
string nmInEng2 = Console.ReadLine();

switch (nmInEng2)
{
    case "fifteen":
        Console.WriteLine("15");
        break;
    default:
        Console.WriteLine("Wrong.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.Write("Enter j character : ");
char ch3 = Convert.ToChar(Console.ReadLine());

switch (ch3)
{
    case 'j':
        Console.WriteLine("Java.");
        break;
    default:
        Console.WriteLine("Wrong character.");
        break;


}

Console.ReadLine();
Console.Clear();

//================================================================


Console.WriteLine("Enter 15 : ");
byte num3 = Convert.ToByte(Console.ReadLine());

switch (num3)
{
    case 15:
        Console.WriteLine("Fifteen.");
        break;
    default:
        Console.WriteLine("Wrong number.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter 10.24 : ");
float point3 = Convert.ToSingle(Console.ReadLine());

switch (point3)
{
    case 10.24F:
        Console.WriteLine("Correct value.");
        break;
    default:
        Console.WriteLine("Wrong command.");
        break;

}

Console.ReadLine();
Console.Clear();

//================================================================

Console.WriteLine("Enter false : ");
bool check3 = Convert.ToBoolean(Console.ReadLine());

switch (check3)
{
    case false:
        Console.WriteLine("Not a Student.");
        break;
    default:
        Console.WriteLine("Out of option.");
        break;
}

Console.ReadLine();
Console.Clear();*/

//================================================================

Console.Write("Enter S character : ");
char ch4 = Convert.ToChar(Console.ReadLine());

switch (ch4)
{
    case 'S':
        Console.WriteLine("SQL.");
        break;
    default:
        Console.WriteLine("Wrong character.");
        break;


}

Console.ReadLine();
Console.Clear();

//================================================================













