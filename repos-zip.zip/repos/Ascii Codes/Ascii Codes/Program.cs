using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ascii_Codes
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Enter any number : ");
            int asciicode = Convert.ToInt32(Console.ReadLine());

            char ch = Convert.ToChar(asciicode);

            Console.WriteLine(ch);

            Console.WriteLine($"Ascii code : {asciicode}");
            Console.WriteLine($"Char : {ch}");


            Console.ReadLine();
            Console.Clear();




            Console.Write("Enter any alpha : ");
            char ch2 = Convert.ToChar(Console.ReadLine());

            int asciicode2 = Convert.ToInt32(ch2);

            Console.WriteLine($"Aplha : {ch2}");
            Console.WriteLine($"Asciicode : {asciicode2}");




            /*Sir string me translate karte waqt error nahi araha lekin output per 
            error de raha he 
            Console.Write("Enter any name : ");
            string name = Console.ReadLine();

            int asciicode3 = Convert.ToInt32(name);

            Console.WriteLine($"Name : {name}");
            Console.WriteLine($"Asciicode : {asciicode3}");*/


            Console.ReadLine();
        }
    }
}
