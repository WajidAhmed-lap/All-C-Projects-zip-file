using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IF_with_Relational_2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ahmed";



            Console.Write("Enter temprature : ");
            sbyte temp = Convert.ToSByte(Console.ReadLine());

            if (temp <= 5)
            { Console.WriteLine("Warning.Is too cold outside."); }
            else { Console.WriteLine("Normal."); }
            Console.ReadLine();
            Console.Clear();


            //                  ==============================      \\

            Console.WriteLine("You want to buy something : ");
            byte quantity = Convert.ToByte(Console.ReadLine());

            if (quantity < 10)
            { Console.WriteLine("You are not eligible to get discount."); }
            else { Console.WriteLine("Yes. You can"); }
            Console.ReadLine();
            Console.Clear();

            //      ====================================================================

            Console.Write("Checking speed : ");
            byte speed = Convert.ToByte(Console.ReadLine());


            if (speed < 60)
            { Console.WriteLine("You are within the speed."); }
            else { Console.WriteLine("You are out of speed."); }


            Console.ReadLine();
            Console.Clear();

            //========================================================


            Console.WriteLine("Check the stock. ");
            byte stock = Convert.ToByte(Console.ReadLine());

            if (stock < 5)
            { Console.WriteLine("Please restock it."); }
            else { Console.WriteLine("Thanks."); }
            Console.ReadLine();
            Console.Clear();


            //===============================================

            Console.Write("I'm your Battery Assistant.");
            byte battery = Convert.ToByte(Console.ReadLine());

            if (battery <= 20)
            { Console.WriteLine("Low Battery Please charge your device."); }

            Console.ReadLine();
            Console.Clear();

            //=================================================================

            Console.Write("Enter your marks : ");
            byte marks = Convert.ToByte(Console.ReadLine());

            if (marks < 40)
            { Console.WriteLine("You have failed in exam."); }

            Console.ReadLine();
            Console.Clear();

            //====================================================================


            Console.WriteLine("Enter your marks to knowing your Grade : ");
            byte mark1 = Convert.ToByte(Console.ReadLine());

            if (mark1 < 60)
            { Console.WriteLine("Grade C"); }

            Console.ReadLine();
            Console.Clear();

            //==================================================================

            Console.Write("Enter your annual salary : ");
            ushort salary = Convert.ToUInt16(Console.ReadLine());

            if (salary <= 50000)
            { Console.WriteLine("You are not eligibl for income tax."); }

            Console.ReadLine();
            Console.Clear();

            //============================================================
















            Console.ReadLine();

        }
    }
}
