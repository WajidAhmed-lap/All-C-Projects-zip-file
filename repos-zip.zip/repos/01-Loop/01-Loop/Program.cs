using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_Loop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            



























            Console.ReadLine();
        }
    }
}
